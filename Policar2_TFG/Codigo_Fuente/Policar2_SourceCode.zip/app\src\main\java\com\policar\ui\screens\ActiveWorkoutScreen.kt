package com.policar.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.annotation.DrawableRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.SportsTennis
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material.icons.filled.Warning
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.policar.MainActivity
import com.policar.NavRoutes
import com.policar.R
import com.policar.data.model.FutbolBiomechanics
import com.policar.data.model.GymBiomechanics
import com.policar.data.model.GymRepData
import com.policar.data.model.HRZone
import com.policar.data.model.PadelBiomechanics
import com.policar.data.model.StressLevel
import com.policar.data.model.SyncState
import com.policar.data.model.TipoDeporte
import com.policar.data.model.WorkoutSummary
import com.policar.ui.screens.GlassCard
import com.policar.ui.screens.GlassContainer
import com.policar.ui.theme.BackgroundPure
import com.policar.ui.theme.BorderSubtle
import com.policar.ui.theme.NeonCyan
import com.policar.ui.theme.NeonGreen
import com.policar.ui.theme.NeonRed
import com.policar.ui.theme.NeonRedAlert
import com.policar.ui.theme.StatusDanger
import com.policar.ui.theme.StatusGood
import com.policar.ui.theme.NeonYellow
import com.policar.ui.theme.SportFutbol
import com.policar.ui.theme.SportGym
import com.policar.ui.theme.SportPadel
import com.policar.ui.theme.SurfaceCard
import com.policar.ui.theme.SurfaceDark
import com.policar.ui.theme.SurfaceElevated
import com.policar.ui.theme.TextPrimary
import com.policar.ui.theme.TextSecondary
import com.policar.ui.theme.TextTertiary
import com.policar.ui.viewmodel.WorkoutViewModel
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

private fun computeHrZone(hr: Int): HRZone = when {
    hr == 0 -> HRZone.ZONE_1
    hr < 100 -> HRZone.ZONE_1
    hr < 130 -> HRZone.ZONE_2
    hr < 160 -> HRZone.ZONE_3
    hr < 180 -> HRZone.ZONE_4
    else -> HRZone.ZONE_5
}

private fun computeStressLevel(stress: Double): StressLevel = when {
    stress < 20.0 -> StressLevel.VERY_LOW
    stress < 40.0 -> StressLevel.LOW
    stress < 60.0 -> StressLevel.MODERATE
    stress < 80.0 -> StressLevel.HIGH
    else          -> StressLevel.VERY_HIGH
}

// Pantalla de entrenamiento activo — muestra BPM en tiempo real, ECG, HRV y biomecánica según el deporte elegido
@Composable
fun ActiveWorkoutScreen(
    navController: NavController,
    viewModel: WorkoutViewModel
) {
    val uiState        by viewModel.uiState.collectAsStateWithLifecycle()
    val heartRate     by viewModel.hrValue.collectAsStateWithLifecycle()
    val hrvStress    by viewModel.hrvStress.collectAsStateWithLifecycle()
    val rmssdVal     by viewModel.rmssd.collectAsStateWithLifecycle()
    val rrIntervalMs by viewModel.rrIntervalMs.collectAsStateWithLifecycle()
    val ecgSamples   by viewModel.ecgSamples.collectAsStateWithLifecycle()
    val recording   by viewModel.recordingStatus.collectAsStateWithLifecycle()
    val tick        by viewModel.tick.collectAsStateWithLifecycle()
    val futbolBio   by viewModel.futbolBio.collectAsStateWithLifecycle()
    val padelBio    by viewModel.padelBio.collectAsStateWithLifecycle()
    val gymBio      by viewModel.gymBio.collectAsStateWithLifecycle()
    val haptic      = LocalHapticFeedback.current
    val context     = LocalContext.current

    DisposableEffect(Unit) {
        (context as? MainActivity)?.setKeepScreenOn(true)
        onDispose {
            (context as? MainActivity)?.setKeepScreenOn(false)
        }
    }

    var showStopDialog    by remember { mutableStateOf(false) }
    var showDiscardDialog by remember { mutableStateOf(false) }
    var showRpeDialog     by remember { mutableStateOf(false) }
    var selectedRpe       by remember { mutableStateOf(5) }
    var showSuccessScreen by remember { mutableStateOf(false) }

    BackHandler(enabled = uiState.isActive && !uiState.isSaving) {
        showStopDialog = true
    }

    LaunchedEffect(uiState.savedSuccessfully, uiState.savedWorkoutSummary) {
        if (uiState.savedSuccessfully && uiState.savedWorkoutSummary != null) {
            showSuccessScreen = true
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BackgroundPure)
    ) {
        if (showSuccessScreen && uiState.savedWorkoutSummary != null) {
            WorkoutSavedScreen(
                summary = uiState.savedWorkoutSummary!!,
                onExit = {
                    showSuccessScreen = false
                    viewModel.resetWorkout()
                    navController.popBackStack(NavRoutes.HOME, inclusive = false)
                }
            )
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                WorkoutTopBar(
                    sport          = viewModel.selectedSport,
                    elapsedSeconds = uiState.elapsedSeconds,
                    isPaused       = uiState.isPaused,
                    batteryLevel   = viewModel.batteryLevel,
                    onPauseResume  = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (uiState.isPaused) viewModel.resumeWorkout()
                        else viewModel.pauseWorkout()
                    },
                    onStop = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        showStopDialog = true
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                LiveTelemetryHeader()

                BpmHeroSection(
                    heartRate = heartRate,
                    hrZone    = computeHrZone(heartRate),
                    rmssd     = rmssdVal.toFloat(),
                    rrMs      = rrIntervalMs
                )

                HrZoneBand(hrZone = computeHrZone(heartRate))

                Spacer(modifier = Modifier.height(8.dp))

                EcgWaveform(samples = ecgSamples)

                Spacer(modifier = Modifier.height(12.dp))

                HrvPanel(
                    rmssd       = rmssdVal.toFloat(),
                    stressLevel = computeStressLevel(hrvStress),
                    rrInterval  = rrIntervalMs
                )

                Spacer(modifier = Modifier.height(12.dp))

                when (viewModel.selectedSport) {
                    TipoDeporte.FUTBOL -> FutbolBiomechanicsPanel(
                        data = futbolBio,
                        currentGForce = futbolBio.currentGForce,
                        isImpact = futbolBio.currentGForce > 1.5f
                    )
                    TipoDeporte.PADEL -> PadelBiomechanicsPanel(
                        data = padelBio,
                        currentX = padelBio.currentXmG.toInt(),
                        currentY = padelBio.currentYmG.toInt()
                    )
                    TipoDeporte.GIMNASIO -> GymBiomechanicsPanel(
                        data = gymBio,
                        velocityAlert = gymBio.velocityLossPct > 20f
                    )
                }

                Spacer(modifier = Modifier.height(40.dp))
            }

            if (uiState.syncState is SyncState.Uploading || uiState.syncState is SyncState.Downloading) {
                SyncLoadingOverlay()
            }
        }

        // ─── Premium full-screen overlays ────────────────────────────────────
        if (showStopDialog) {
            StopWorkoutOverlay(
                onSave     = { showStopDialog = false; showRpeDialog = true },
                onDiscard  = { showStopDialog = false; showDiscardDialog = true },
                onContinue = { showStopDialog = false }
            )
        }

        if (showDiscardDialog) {
            DiscardWorkoutOverlay(
                onConfirm = {
                    showDiscardDialog = false
                    viewModel.discardWorkout()
                    navController.popBackStack(NavRoutes.HOME, inclusive = false)
                },
                onCancel = { showDiscardDialog = false }
            )
        }

        if (showRpeDialog) {
            RpeOverlay(
                selectedRpe   = selectedRpe,
                onRpeSelected = { selectedRpe = it },
                hrSamples     = viewModel.telemetry.hrHistory,
                onConfirm     = { showRpeDialog = false; viewModel.saveWorkout(selectedRpe) },
                onDismiss     = { showRpeDialog = false; viewModel.saveWorkout(0) }
            )
        }
    }
}

// Pantalla de confirmación tras guardar — muestra el resumen de la sesión con deporte, duración y FC máxima
@Composable
private fun WorkoutSavedScreen(
    summary: WorkoutSummary,
    onExit: () -> Unit
) {
    val sportIcon: ImageVector = when (summary.sportType.uppercase()) {
        "FUTBOL" -> Icons.Default.SportsSoccer
        "PADEL" -> Icons.Default.SportsTennis
        else -> Icons.Default.FitnessCenter
    }

    val sportColor = when (summary.sportType.uppercase()) {
        "FUTBOL" -> SportFutbol
        "PADEL" -> SportPadel
        "GIMNASIO" -> SportGym
        else -> NeonCyan
    }

    val sportLabel = when (summary.sportType.uppercase()) {
        "FUTBOL" -> "Futbol"
        "PADEL" -> "Padel"
        "GIMNASIO" -> "Gimnasio"
        else -> summary.sportType
    }

    val dateFormatter = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
    val timeFormatter = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
    val startDateStr = dateFormatter.format(java.util.Date(summary.startTime))
    val startTimeStr = timeFormatter.format(java.util.Date(summary.startTime))
    val endDateStr = dateFormatter.format(java.util.Date(summary.endTime))
    val endTimeStr = timeFormatter.format(java.util.Date(summary.endTime))

    val hours = summary.durationSeconds / 3600
    val minutes = (summary.durationSeconds % 3600) / 60
    val seconds = summary.durationSeconds % 60
    val durationStr = if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040404)),
        contentAlignment = Alignment.Center
    ) {
        // Sport ambient glow behind content
        Box(
            modifier = Modifier
                .size(350.dp)
                .offset(y = (-80).dp)
                .align(Alignment.TopCenter)
                .alpha(0.20f)
                .blur(100.dp)
                .background(
                    Brush.radialGradient(listOf(sportColor, Color.Transparent)),
                    shape = CircleShape
                )
        )
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp, vertical = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(
                        Brush.radialGradient(listOf(sportColor.copy(alpha = 0.28f), sportColor.copy(alpha = 0.05f))),
                        CircleShape
                    )
                    .drawBehind {
                        drawCircle(
                            color = sportColor.copy(alpha = 0.45f),
                            radius = size.minDimension / 2,
                            style = Stroke(width = 1.dp.toPx())
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = sportIcon,
                    contentDescription = null,
                    modifier = Modifier.size(40.dp),
                    tint = sportColor
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "SESSION COMPLETE",
                fontSize = 24.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                letterSpacing = 3.sp,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(6.dp).background(NeonGreen, CircleShape))
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "SYNCED TO CLOUD",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonGreen.copy(alpha = 0.85f),
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Summary card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF191919), Color(0xFF0E0E0E))))
                    .drawBehind {
                        val cr = 20.dp.toPx()
                        drawRoundRect(
                            brush = Brush.linearGradient(listOf(sportColor.copy(0.40f), Color(0x0AFFFFFF), Color(0x06FFFFFF))),
                            cornerRadius = CornerRadius(cr), style = Stroke(1.5.dp.toPx())
                        )
                        drawLine(
                            brush = Brush.horizontalGradient(
                                listOf(Color.Transparent, sportColor.copy(0.75f), sportColor.copy(0.75f), Color.Transparent),
                                startX = size.width * 0.08f, endX = size.width * 0.92f
                            ),
                            start = Offset(0f, 0f), end = Offset(size.width, 0f),
                            strokeWidth = 1.5.dp.toPx()
                        )
                    }
                    .padding(24.dp)
            ) {
                Column {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryStat(label = "INICIO", value = startTimeStr, sub = startDateStr, color = TextPrimary, modifier = Modifier.weight(1f))
                        SummaryStat(label = "FIN", value = endTimeStr, sub = endDateStr, color = TextPrimary, modifier = Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(14.dp))
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(0.07f)))
                    Spacer(Modifier.height(14.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SummaryStat(label = "DURACIÓN", value = durationStr, color = NeonCyan, modifier = Modifier.weight(1f))
                        SummaryStat(label = "FC MAX", value = "${summary.maxHr}", sub = "bpm", color = NeonRed, modifier = Modifier.weight(1f))
                        SummaryStat(label = "DEPORTE", value = sportLabel.uppercase(), color = sportColor, modifier = Modifier.weight(1f))
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Exit button with gradient + shine
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(62.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF8B0016), NeonRed, Color(0xFFCC001C))))
                    .drawBehind {
                        drawLine(
                            brush = Brush.horizontalGradient(listOf(
                                Color.Transparent, Color.White.copy(0.28f), Color.White.copy(0.28f), Color.Transparent
                            )),
                            start = Offset(size.width * 0.12f, 1.5f),
                            end = Offset(size.width * 0.88f, 1.5f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .clickable { onExit() },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "IR AL INICIO",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 2.sp,
                    color = Color.White
                )
            }
        }
    }
}

// Barra superior del entrenamiento: deporte activo, cronómetro animado y botones de pausa y stop
@Composable
private fun WorkoutTopBar(
    sport: TipoDeporte,
    elapsedSeconds: Long,
    isPaused: Boolean,
    batteryLevel: Int,
    onPauseResume: () -> Unit,
    onStop: () -> Unit
) {
    val hours   = elapsedSeconds / 3600
    val minutes = (elapsedSeconds % 3600) / 60
    val seconds = elapsedSeconds % 60
    val timeStr = if (hours > 0) {
        "%d:%02d:%02d".format(hours, minutes, seconds)
    } else {
        "%02d:%02d".format(minutes, seconds)
    }

    val topBarSportColor = when (sport) {
        TipoDeporte.FUTBOL   -> SportFutbol
        TipoDeporte.PADEL    -> SportPadel
        TipoDeporte.GIMNASIO -> SportGym
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF080808), Color(0xFF0D0D0D))
                )
            )
            .drawBehind {
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            topBarSportColor.copy(alpha = 0.55f),
                            topBarSportColor.copy(alpha = 0.30f),
                            Color.Transparent
                        )
                    ),
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val sportIcon: ImageVector = when (sport) {
                TipoDeporte.FUTBOL   -> Icons.Default.SportsSoccer
                TipoDeporte.PADEL    -> Icons.Default.SportsTennis
                TipoDeporte.GIMNASIO -> Icons.Default.FitnessCenter
            }
            val sportColor = topBarSportColor
            Icon(
                imageVector = sportIcon,
                contentDescription = sport.displayName,
                modifier = Modifier.size(22.dp),
                tint = sportColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
                Text(
                    text       = sport.displayName.uppercase(),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize   = 15.sp,
                    color      = topBarSportColor,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text  = "POLAR H10",
                    fontSize = 9.sp,
                    color = NeonGreen,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                    letterSpacing = 0.5.sp
                )
            }
        }

        AnimatedContent(
            targetState   = timeStr,
            transitionSpec = {
                slideInVertically { -it } + fadeIn() togetherWith
                        slideOutVertically { it } + fadeOut()
            },
            label = "timer"
        ) { time ->
            Text(
                text       = time,
                fontWeight = FontWeight.Black,
                fontSize   = 26.sp,
                color      = if (isPaused) NeonYellow else TextPrimary,
                letterSpacing = 2.sp,
                fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(
                onClick  = onPauseResume,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(SurfaceElevated)
            ) {
                Icon(
                    imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                    contentDescription = if (isPaused) "Reanudar" else "Pausar",
                    tint = NeonYellow,
                    modifier = Modifier.size(20.dp)
                )
            }
            IconButton(
                onClick  = onStop,
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(StatusDanger.copy(alpha = 0.15f))
            ) {
                Icon(
                    imageVector = Icons.Default.Stop,
                    contentDescription = "Detener",
                    tint = StatusDanger,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

// Sección principal de FC — anillo circular con la zona cardíaca y el número de BPM en grande
@Composable
private fun BpmHeroSection(
    heartRate: Int,
    hrZone: HRZone,
    rmssd: Float,
    rrMs: Long
) {
    val zoneColor = when (hrZone) {
        HRZone.ZONE_1 -> StatusGood
        HRZone.ZONE_2 -> NeonGreen
        HRZone.ZONE_3 -> NeonYellow
        HRZone.ZONE_4 -> Color(0xFFFF9100)
        HRZone.ZONE_5 -> StatusDanger
    }

    val beatDurationMs = if (rrMs > 0) rrMs.toInt() else 800
    val infiniteTransition = rememberInfiniteTransition(label = "bpm_glow")
    val glowRadius by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(beatDurationMs / 2, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bpm_pulse"
    )
    val beatScale by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(beatDurationMs / 2, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "beat_scale"
    )
    val arcFill by animateFloatAsState(
        targetValue = (heartRate.toFloat() / 200f).coerceIn(0f, 1f),
        animationSpec = tween(900, easing = FastOutSlowInEasing),
        label = "arc_fill"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
    ) {
        // Arc ring
        Canvas(modifier = Modifier.size(272.dp)) {
            val sw = 11.dp.toPx()
            val inset = sw / 2f
            val arcRect = Size(size.width - sw, size.height - sw)
            val arcOffset = Offset(inset, inset)
            // Background track
            drawArc(
                color = Color.White.copy(alpha = 0.055f),
                startAngle = 135f, sweepAngle = 270f,
                useCenter = false, topLeft = arcOffset, size = arcRect,
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            // Zone fill
            if (arcFill > 0.01f) {
                drawArc(
                    color = zoneColor,
                    startAngle = 135f, sweepAngle = 270f * arcFill,
                    useCenter = false, topLeft = arcOffset, size = arcRect,
                    style = Stroke(width = sw, cap = StrokeCap.Round)
                )
            }
        }

        // Inner glow behind number
        Box(
            modifier = Modifier
                .size(195.dp)
                .alpha(glowRadius * 0.38f)
                .background(Brush.radialGradient(listOf(zoneColor.copy(alpha = 0.62f), Color.Transparent)), CircleShape)
                .blur(48.dp)
        )

        // Number + zone info
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.scale(beatScale)
        ) {
            AnimatedContent(
                targetState = heartRate,
                transitionSpec = {
                    if (targetState > initialState) {
                        slideInVertically { -it } + fadeIn() togetherWith slideOutVertically { it } + fadeOut()
                    } else {
                        slideInVertically { it } + fadeIn() togetherWith slideOutVertically { -it } + fadeOut()
                    }
                },
                label = "bpm_odometer"
            ) { bpm ->
                Text(
                    text = if (bpm > 0) "$bpm" else "--",
                    fontWeight = FontWeight.Black,
                    fontSize = 96.sp,
                    color = zoneColor,
                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("BPM", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = zoneColor.copy(alpha = 0.75f), letterSpacing = 3.sp)
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(zoneColor.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(hrZone.label.uppercase(), fontSize = 9.sp, fontWeight = FontWeight.Bold, color = zoneColor, letterSpacing = 1.sp)
                }
            }
        }
    }
}

// Panel de variabilidad cardíaca con RMSSD, nivel de estrés estimado e intervalo R-R
@Composable
private fun HrvPanel(
    rmssd: Float,
    stressLevel: StressLevel,
    rrInterval: Long
) {
    val stressColor = when (stressLevel) {
        StressLevel.VERY_LOW, StressLevel.LOW   -> NeonGreen
        StressLevel.MODERATE                    -> NeonYellow
        StressLevel.HIGH, StressLevel.VERY_HIGH -> StatusDanger
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF141414), Color(0xFF0F0F0F))))
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(NeonCyan.copy(0.22f), Color(0x0AFFFFFF), Color(0x06FFFFFF))),
                    cornerRadius = CornerRadius(14.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
                drawLine(
                    brush = Brush.horizontalGradient(listOf(Color.Transparent, NeonCyan.copy(0.70f), NeonCyan.copy(0.70f), Color.Transparent), startX = size.width * 0.05f, endX = size.width * 0.95f),
                    start = Offset(0f, 0f), end = Offset(size.width, 0f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            .padding(horizontal = 8.dp, vertical = 14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            HrvStat(label = "HRV RMSSD", value = "${"%.0f".format(rmssd)}", unit = "ms", color = NeonCyan)
            Box(Modifier.width(1.dp).height(32.dp).background(Color.White.copy(alpha = 0.08f)))
            HrvStat(label = "ESTRÉS", value = stressLevel.label, unit = "", color = stressColor)
            Box(Modifier.width(1.dp).height(32.dp).background(Color.White.copy(alpha = 0.08f)))
            HrvStat(label = "R-R INTERVAL", value = "$rrInterval", unit = "ms", color = TextSecondary)
        }
    }
}

@Composable
private fun HrvStat(label: String, value: String, unit: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(text = value, fontSize = 20.sp, fontWeight = FontWeight.Black, color = color, fontFamily = FontFamily.Monospace)
            if (unit.isNotBlank()) {
                Spacer(Modifier.width(2.dp))
                Text(text = unit, fontSize = 8.sp, color = TextTertiary, modifier = Modifier.padding(bottom = 3.dp), fontFamily = FontFamily.Monospace)
            }
        }
        Spacer(Modifier.height(2.dp))
        Text(text = label, fontSize = 7.sp, color = TextTertiary.copy(alpha = 0.60f), letterSpacing = 0.8.sp, fontFamily = FontFamily.Monospace)
    }
}

// Panel de biomecánica para Fútbol: G-Force actual, impactos, sprints, saltos y balance de carga
@Composable
private fun FutbolBiomechanicsPanel(data: FutbolBiomechanics, currentGForce: Float, isImpact: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "impact")
    val impactAlpha by infiniteTransition.animateFloat(initialValue = 0.4f, targetValue = 1f, animationSpec = infiniteRepeatable(tween(300), RepeatMode.Reverse), label = "impact_alpha")

    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(sportIcon = Icons.Default.SportsSoccer, title = "BIOMECHANICS · FOOTBALL", color = SportFutbol)
        Spacer(modifier = Modifier.height(10.dp))

        GlassCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "ACELERACION NETA", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        if (data.isCurrentlySprinting) {
                            Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(NeonYellow.copy(alpha = 0.2f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                Text(text = "SPRINT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = NeonYellow, letterSpacing = 1.sp)
                            }
                        }
                        if (isImpact) {
                            Box(modifier = Modifier.alpha(impactAlpha).clip(RoundedCornerShape(4.dp)).background(StatusDanger.copy(alpha = 0.2f)).padding(horizontal = 8.dp, vertical = 2.dp)) {
                                Text(text = "IMPACT", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = StatusDanger, letterSpacing = 1.sp)
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "${"%.2f".format(currentGForce)} G", fontWeight = FontWeight.Black, fontSize = 32.sp, color = if (isImpact) StatusDanger else if (data.isCurrentlySprinting) NeonYellow else SportFutbol)
                Spacer(modifier = Modifier.height(8.dp))
                GForceBar(normalized = min(currentGForce / 4f, 1f))
            }
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(modifier = Modifier.weight(1f), label = "IMPACTOS", value = "${data.totalImpacts}", unit = "", color = SportFutbol, icon = Icons.Default.FlashOn)
            MetricCard(modifier = Modifier.weight(1f), label = "ALTA INTENS.", value = "${data.highIntensityImpacts}", unit = ">3G", color = StatusDanger, icon = Icons.AutoMirrored.Filled.TrendingUp)
            MetricCard(modifier = Modifier.weight(1f), label = "G MAX", value = "${"%.1f".format(data.maxGForce)}", unit = "G", color = NeonYellow, icon = Icons.Default.KeyboardArrowUp)
        }

        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(modifier = Modifier.weight(1f), label = "SPRINTS", value = "${data.sprintCount}", unit = "", color = NeonYellow, icon = Icons.Default.DirectionsRun)
            MetricCard(modifier = Modifier.weight(1f), label = "SALTOS", value = "${data.jumpCount}", unit = "", color = NeonCyan, icon = Icons.Default.KeyboardArrowUp)
            MetricCard(modifier = Modifier.weight(1f), label = "ASIMETRIA", value = "${"%.0f".format(data.asymmetryScore)}", unit = "%", color = if (data.asymmetryScore < 15f) NeonGreen else NeonYellow, icon = Icons.Default.Balance)
        }

        Spacer(modifier = Modifier.height(10.dp))
        GlassCard {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(text = "BALANCE DE CARGA", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    LoadBar(label = "Mecánica", value = data.mechanicalLoadScore, maxValue = 10f, color = SportFutbol, modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(16.dp))
                    LoadBar(label = "Cardiovascular", value = data.cardiovascularLoadScore, maxValue = 100f, color = NeonRed, modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

// Panel de biomecánica para Pádel: smashes detectados y rotación de tronco en ejes X e Y
@Composable
private fun PadelBiomechanicsPanel(data: PadelBiomechanics, currentX: Int, currentY: Int) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(sportIcon = Icons.Default.SportsTennis, title = "BIOMECHANICS · PADEL", color = SportPadel)
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(modifier = Modifier.weight(1f), label = "SMASHES", value = "${data.totalSmashes}", unit = "", color = SportPadel, icon = Icons.Default.FlashOn)
            MetricCard(modifier = Modifier.weight(1f), label = "ROT. PICO", value = "${"%.0f".format(data.maxRotationDps)}", unit = "deg/s", color = NeonCyan, icon = Icons.AutoMirrored.Filled.RotateRight)
            MetricCard(modifier = Modifier.weight(1f), label = "ASIMETRIA", value = "${"%.0f".format(data.asymmetryScore * 100)}", unit = "%", color = if (data.asymmetryScore < 0.2f) NeonGreen else NeonYellow, icon = Icons.Default.Balance)
        }
        Spacer(modifier = Modifier.height(10.dp))
        GlassCard {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "ROTACIÓN DE TRONCO (X/Y)", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("EJE X", fontSize = 9.sp, color = NeonCyan)
                            Text("${currentX} mG", fontSize = 9.sp, color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        AxisBar(value = currentX, max = 3000, color = NeonCyan)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("EJE Y", fontSize = 9.sp, color = SportPadel)
                            Text("${currentY} mG", fontSize = 9.sp, color = TextSecondary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        AxisBar(value = currentY, max = 3000, color = SportPadel)
                    }
                }
            }
        }
    }
}

// Panel de biomecánica para Gimnasio: repeticiones, series y velocidad concéntrica por rep
@Composable
private fun GymBiomechanicsPanel(data: GymBiomechanics, velocityAlert: Boolean) {
    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
        SectionHeader(sportIcon = Icons.Default.FitnessCenter, title = "BIOMECHANICS · GYM", color = SportGym)
        Spacer(modifier = Modifier.height(10.dp))

        AnimatedVisibility(visible = velocityAlert) {
            Row(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(StatusDanger.copy(alpha = 0.12f)).border(1.dp, StatusDanger.copy(alpha = 0.3f), RoundedCornerShape(10.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.Warning, contentDescription = null, tint = StatusDanger, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "Velocidad concéntrica -${"%.0f".format(data.velocityLossPct)}%", fontSize = 12.sp, color = StatusDanger, fontWeight = FontWeight.Medium)
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            MetricCard(modifier = Modifier.weight(1f), label = "REPS", value = "${data.totalReps}", unit = "", color = SportGym, icon = Icons.Default.Repeat)
            MetricCard(modifier = Modifier.weight(1f), label = "SERIES", value = "${data.totalSets}", unit = "", color = NeonYellow, icon = Icons.Default.FitnessCenter)
            MetricCard(modifier = Modifier.weight(1f), label = "VELOCIDAD", value = "${"%.2f".format(data.avgVelocityMs)}", unit = "m/s", color = if (!velocityAlert) NeonGreen else StatusDanger, icon = Icons.Default.Speed)
        }

        if (data.repsData.isNotEmpty()) {
            Spacer(modifier = Modifier.height(10.dp))
            GlassCard {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "VELOCIDAD POR REP", fontSize = 10.sp, color = TextTertiary, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    VelocitySparklineChart(reps = data.repsData)
                }
            }
        }
    }
}

@Composable
private fun RpeDialog(selectedRpe: Int, onRpeSelected: (Int) -> Unit, hrSamples: List<Int>, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        titleContentColor = TextPrimary,
        title = { Column { Text("Esfuerzo Percibido (RPE)", fontWeight = FontWeight.Bold); Text(text = "Escala CR10 de Borg", fontSize = 11.sp, color = TextTertiary) } },
        text = {
            Column {
                if (hrSamples.size > 5) {
                    Text(text = "PULSO DE LA SESIÓN", fontSize = 9.sp, color = TextTertiary, letterSpacing = 1.sp, modifier = Modifier.padding(bottom = 6.dp))
                    HrSparkline(samples = hrSamples, modifier = Modifier.fillMaxWidth().height(60.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                }
                Text(text = "¿Cómo fue el esfuerzo?", fontSize = 13.sp, color = TextSecondary, modifier = Modifier.padding(bottom = 12.dp))
                Slider(value = selectedRpe.toFloat(), onValueChange = { onRpeSelected(it.toInt()) }, valueRange = 1f..10f, steps = 8, colors = SliderDefaults.colors(thumbColor = NeonRed, activeTrackColor = NeonRed, inactiveTrackColor = SurfaceElevated))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("Muy fácil", fontSize = 9.sp, color = NeonGreen); Text(text = "RPE $selectedRpe/10", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = NeonRed); Text("Máximo", fontSize = 9.sp, color = StatusDanger) }
                val rpeLabel = when (selectedRpe) { 1, 2 -> "Muy ligero"; 3, 4 -> "Ligero"; 5, 6 -> "Moderado"; 7, 8 -> "Duro"; 9 -> "Muy duro"; 10 -> "Esfuerzo máximo"; else -> "" }
                Text(text = rpeLabel, fontSize = 12.sp, color = TextSecondary, modifier = Modifier.fillMaxWidth().padding(top = 4.dp), textAlign = TextAlign.Center)
            }
        },
        confirmButton = { Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = NeonRed)) { Icon(imageVector = Icons.Default.CloudDone, contentDescription = null, modifier = Modifier.size(16.dp)); Spacer(modifier = Modifier.width(6.dp)); Text("Guardar en Supabase") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Omitir", color = TextTertiary) } }
    )
}

// Mini gráfico de línea con el historial de FC de la sesión — se usa en el overlay RPE
@Composable
fun HrSparkline(samples: List<Int>, modifier: Modifier = Modifier) {
    if (samples.size < 2) return
    val minHr = samples.minOrNull() ?: 0
    val maxHr = samples.maxOrNull() ?: 1
    val range = maxOf(maxHr - minHr, 1)

    Canvas(modifier = modifier.clip(RoundedCornerShape(8.dp))) {
        val w = size.width
        val h = size.height
        val stepX = w / (samples.size - 1).toFloat()

        val path = Path()
        val fillPath = Path()

        samples.forEachIndexed { i, hr ->
            val x = i * stepX
            val norm = (hr - minHr).toFloat() / range.toFloat()
            val y = h - (norm * h * 0.85f) - h * 0.075f

            if (i == 0) { path.moveTo(x, y); fillPath.moveTo(x, h); fillPath.lineTo(x, y) }
            else { path.lineTo(x, y); fillPath.lineTo(x, y) }
        }
        fillPath.lineTo(w, h)
        fillPath.close()

        drawPath(path = fillPath, brush = Brush.verticalGradient(listOf(NeonRed.copy(alpha = 0.3f), Color.Transparent)))
        drawPath(path = path, color = NeonRed, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
    }
}

// Gráfico de velocidad concéntrica por repetición — marca en rojo las reps con pérdida excesiva
@Composable
private fun VelocitySparklineChart(reps: List<GymRepData>) {
    if (reps.size < 2) return
    val maxV = reps.maxOfOrNull { it.meanVelocity }?.takeIf { it > 0f } ?: 1f

    Canvas(modifier = Modifier.fillMaxWidth().height(50.dp)) {
        val w = size.width
        val h = size.height
        val stepX = w / (reps.size - 1).toFloat()

        val path = Path()
        reps.forEachIndexed { i, rep ->
            val x = i * stepX
            val norm = rep.meanVelocity / maxV
            val y = h - norm * h * 0.9f
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(path = path, color = NeonGreen, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))

        reps.forEachIndexed { i, rep ->
            val x = i * stepX
            val norm = rep.meanVelocity / maxV
            val y = h - norm * h * 0.9f
            val color = if (rep.velocityLossPct > 20f) StatusDanger else NeonGreen
            drawCircle(color = color, radius = 4.dp.toPx(), center = Offset(x, y))
        }
    }
}

// Tarjeta de métrica con icono, valor animado y etiqueta. El borde superior cambia de color según el tipo
@Composable
private fun MetricCard(modifier: Modifier = Modifier, label: String, value: String, unit: String, color: Color, icon: ImageVector) {
    val cardCorner = 13.dp
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cardCorner))
            .background(brush = Brush.verticalGradient(colors = listOf(Color(0xFF1C1C1C), Color(0xFF0F0F0F))))
            .drawBehind {
                val cr = cardCorner.toPx()
                // Outer border
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(color.copy(alpha = 0.40f), Color(0x0EFFFFFF), Color(0x08FFFFFF))
                    ),
                    cornerRadius = CornerRadius(cr),
                    style = Stroke(width = 1.dp.toPx())
                )
                // Top accent line in card color
                drawLine(
                    brush = Brush.horizontalGradient(
                        colors = listOf(Color.Transparent, color.copy(alpha = 0.80f), color.copy(alpha = 0.80f), Color.Transparent),
                        startX = size.width * 0.1f, endX = size.width * 0.9f
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            .padding(12.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .background(color.copy(alpha = 0.14f), RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(15.dp))
            }
            Spacer(modifier = Modifier.height(7.dp))
            AnimatedContent(
                targetState = value,
                transitionSpec = { slideInVertically { -it } + fadeIn() togetherWith slideOutVertically { it } + fadeOut() },
                label = "metric_$label"
            ) { v ->
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(text = v, fontWeight = FontWeight.Black, fontSize = 24.sp, color = color, fontFamily = FontFamily.Monospace)
                    if (unit.isNotBlank()) {
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(text = unit, fontSize = 8.sp, color = TextTertiary, modifier = Modifier.padding(bottom = 4.dp), fontFamily = FontFamily.Monospace)
                    }
                }
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, fontSize = 7.5.sp, color = TextTertiary.copy(alpha = 0.65f), letterSpacing = 0.5.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

// Cabecera de sección con barra de acento, icono y línea decorativa del color del deporte
@Composable
private fun SectionHeader(sportIcon: ImageVector, title: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            modifier = Modifier
                .width(3.dp)
                .height(20.dp)
                .background(
                    brush = Brush.verticalGradient(listOf(color, color.copy(alpha = 0.15f))),
                    shape = RoundedCornerShape(2.dp)
                )
        )
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier
                .size(30.dp)
                .background(color.copy(alpha = 0.16f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = sportIcon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(9.dp))
        Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.5.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(12.dp))
        Box(
            modifier = Modifier
                .weight(1f)
                .height(1.dp)
                .background(Brush.horizontalGradient(listOf(color.copy(alpha = 0.35f), Color.Transparent)))
        )
    }
}

@Composable
private fun GForceBar(normalized: Float) {
    val color = when { normalized < 0.3f -> NeonGreen; normalized < 0.6f -> NeonYellow; else -> StatusDanger }
    val animNorm by animateFloatAsState(targetValue = normalized, animationSpec = tween(200), label = "gforce_bar")
    Box(modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)).background(SurfaceElevated)) {
        Box(modifier = Modifier.fillMaxWidth(animNorm).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(brush = Brush.horizontalGradient(listOf(NeonGreen, color))))
    }
}

@Composable
private fun AxisBar(value: Int, max: Int, color: Color) {
    val normalized = min(kotlin.math.abs(value).toFloat() / max.toFloat(), 1f)
    val animNorm by animateFloatAsState(targetValue = normalized, animationSpec = tween(100), label = "axis_bar")
    Box(modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(3.dp)).background(SurfaceElevated)) {
        Box(modifier = Modifier.fillMaxWidth(animNorm).fillMaxHeight().clip(RoundedCornerShape(3.dp)).background(color))
    }
}

@Composable
private fun LoadBar(modifier: Modifier = Modifier, label: String, value: Float, maxValue: Float, color: Color) {
    val normalized = min(value / maxValue, 1f)
    Column(modifier = modifier) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, fontSize = 9.sp, color = TextTertiary); Text("${"%.1f".format(value)}", fontSize = 9.sp, color = color) }
        Spacer(modifier = Modifier.height(4.dp))
        Box(modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(SurfaceElevated)) {
            val animNorm by animateFloatAsState(normalized, tween(400), label = "load_$label")
            Box(modifier = Modifier.fillMaxWidth(animNorm).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(color))
        }
    }
}

// ─── ECG real-time waveform ───────────────────────────────────────────────────

// Onda ECG en tiempo real con los datos del Polar H10 — línea cyan animada con área de relleno
@Composable
fun EcgWaveform(samples: List<Float>, modifier: Modifier = Modifier) {
    val displaySamples = if (samples.size > 200) samples.takeLast(200) else samples

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(78.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF080808))
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        listOf(NeonCyan.copy(alpha = 0.25f), Color(0x08FFFFFF), Color(0x06FFFFFF))
                    ),
                    cornerRadius = CornerRadius(12.dp.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
                // Subtle grid
                val gridSpacing = size.width / 8f
                var gx = gridSpacing
                while (gx < size.width) {
                    drawLine(NeonCyan.copy(alpha = 0.04f), Offset(gx, 0f), Offset(gx, size.height), strokeWidth = 0.5f)
                    gx += gridSpacing
                }
                drawLine(NeonCyan.copy(alpha = 0.06f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), strokeWidth = 0.5f)
            }
    ) {
        // Top cyan accent line
        Box(
            Modifier.fillMaxWidth().height(1.5.dp).align(Alignment.TopCenter)
                .background(
                    Brush.horizontalGradient(
                        listOf(Color.Transparent, NeonCyan.copy(0.75f), NeonCyan.copy(0.75f), Color.Transparent),
                        startX = 0.05f, endX = 0.95f
                    )
                )
        )

        // ECG label
        Text(
            text = "ECG",
            fontSize = 7.sp,
            fontWeight = FontWeight.ExtraBold,
            color = NeonCyan.copy(alpha = 0.55f),
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.TopStart).padding(start = 8.dp, top = 5.dp)
        )

        if (displaySamples.size >= 2) {
            Canvas(modifier = Modifier.fillMaxSize().padding(top = 6.dp, bottom = 4.dp)) {
                val minVal = displaySamples.minOrNull() ?: 0f
                val maxVal = displaySamples.maxOrNull() ?: 1f
                val range = (maxVal - minVal).coerceAtLeast(1f)
                val stepX = size.width / (displaySamples.size - 1).toFloat()
                val marginY = size.height * 0.08f

                val path = Path()
                val fillPath = Path()

                displaySamples.forEachIndexed { i, v ->
                    val x = i * stepX
                    val norm = (v - minVal) / range
                    val y = size.height - marginY - norm * (size.height - marginY * 2)
                    if (i == 0) {
                        path.moveTo(x, y)
                        fillPath.moveTo(x, size.height)
                        fillPath.lineTo(x, y)
                    } else {
                        path.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                }
                fillPath.lineTo(size.width, size.height)
                fillPath.close()

                drawPath(fillPath, Brush.verticalGradient(listOf(NeonCyan.copy(alpha = 0.20f), Color.Transparent)))
                // Glow layer
                drawPath(path, color = NeonCyan.copy(alpha = 0.20f), style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round))
                // Main line
                drawPath(path, color = NeonCyan, style = Stroke(width = 1.5.dp.toPx(), cap = StrokeCap.Round))
            }
        } else {
            // Flat line when no ECG data
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawLine(
                    color = NeonCyan.copy(alpha = 0.25f),
                    start = Offset(size.width * 0.05f, size.height / 2),
                    end = Offset(size.width * 0.95f, size.height / 2),
                    strokeWidth = 1.dp.toPx()
                )
            }
        }
    }
}

// ─── LIVE indicator ──────────────────────────────────────────────────────────

// Indicador pulsante que muestra que la telemetría cardíaca está activa y recibiendo datos
@Composable
private fun LiveTelemetryHeader() {
    val infiniteTransition = rememberInfiniteTransition(label = "live_pulse")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 1f, targetValue = 0.2f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "dot"
    )
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(6.dp)
                .alpha(dotAlpha)
                .background(NeonRed, androidx.compose.foundation.shape.CircleShape)
        )
        Spacer(Modifier.width(7.dp))
        Text(
            text = "CARDIAC TELEMETRY",
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TextTertiary.copy(alpha = 0.65f),
            letterSpacing = 2.5.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

// ─── HR Zone band — 5 coloured segments ──────────────────────────────────────

// Banda de 5 segmentos de colores que indica la zona cardíaca actual. El activo es más alto y brillante
@Composable
private fun HrZoneBand(hrZone: HRZone) {
    val zoneColors = listOf(
        StatusGood,
        NeonGreen,
        NeonYellow,
        Color(0xFFFF9100),
        StatusDanger
    )
    val zoneLabels = listOf("Z1", "Z2", "Z3", "Z4", "Z5")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 28.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            zoneColors.forEachIndexed { i, color ->
                val isActive = hrZone.ordinal == i
                val isPast   = hrZone.ordinal > i
                val animAlpha by animateFloatAsState(
                    targetValue = when { isActive -> 1f; isPast -> 0.45f; else -> 0.12f },
                    animationSpec = tween(400),
                    label = "zone_alpha_$i"
                )
                val animHeight by animateFloatAsState(
                    targetValue = if (isActive) 8f else 4f,
                    animationSpec = tween(300),
                    label = "zone_h_$i"
                )
                Column(
                    modifier = Modifier.weight(1f),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(animHeight.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(color.copy(alpha = animAlpha))
                    )
                    if (isActive) {
                        Spacer(Modifier.height(3.dp))
                        Text(
                            text = zoneLabels[i],
                            fontSize = 7.sp,
                            fontWeight = FontWeight.Bold,
                            color = color,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

// ─── WorkoutSavedScreen helper ────────────────────────────────────────────────

// Celda de estadística para el resumen de sesión: etiqueta pequeña arriba y valor grande abajo
@Composable
private fun SummaryStat(label: String, value: String, color: Color, sub: String = "", modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = label, fontSize = 8.sp, color = TextTertiary.copy(0.60f), letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
        Spacer(Modifier.height(4.dp))
        Text(text = value, fontSize = 18.sp, fontWeight = FontWeight.Black, color = color, fontFamily = FontFamily.Monospace)
        if (sub.isNotBlank()) Text(text = sub, fontSize = 9.sp, color = TextTertiary, fontFamily = FontFamily.Monospace)
    }
}

// ─── Sync loading overlay ─────────────────────────────────────────────────────

// Pantalla de espera mientras se sube la sesión a Supabase — círculo con glow pulsante en rojo
@Composable
private fun SyncLoadingOverlay() {
    val infiniteTransition = rememberInfiniteTransition(label = "sync")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "sync_pulse"
    )
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.88f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier.size(80.dp)
                    .drawBehind {
                        for (i in 0..2) {
                            drawCircle(
                                color = NeonRed.copy(alpha = pulse * 0.08f * (3 - i)),
                                radius = size.minDimension / 2 + (i * 12).dp.toPx()
                            )
                        }
                    }
                    .background(Color(0xFF1A0000), CircleShape)
                    .border(1.5.dp, NeonRed.copy(alpha = pulse * 0.70f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = NeonRed, modifier = Modifier.size(36.dp), strokeWidth = 2.5.dp)
            }
            Spacer(Modifier.height(20.dp))
            Text("GUARDANDO SESIÓN", fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = TextPrimary)
            Spacer(Modifier.height(6.dp))
            Text("Sincronizando con Supabase...", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextTertiary, letterSpacing = 0.5.sp)
        }
    }
}

// ─── Stop workout overlay ─────────────────────────────────────────────────────

// Sheet que aparece al pulsar stop: tres opciones claramente diferenciadas — guardar, continuar o descartar
@Composable
private fun StopWorkoutOverlay(onSave: () -> Unit, onDiscard: () -> Unit, onContinue: () -> Unit) {
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.90f)).clickable { onContinue() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color(0xFF111111))
                .drawBehind {
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, NeonRed.copy(0.65f), NeonRed.copy(0.65f), Color.Transparent),
                            startX = size.width * 0.08f, endX = size.width * 0.92f
                        ),
                        start = Offset(0f, 0f), end = Offset(size.width, 0f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
                .clickable(indication = null, interactionSource = androidx.compose.foundation.interaction.MutableInteractionSource().let { remember { it } }) { }
                .padding(horizontal = 24.dp, vertical = 28.dp)
        ) {
            Box(Modifier.size(40.dp, 4.dp).align(Alignment.CenterHorizontally).background(Color.White.copy(0.15f), RoundedCornerShape(2.dp)))
            Spacer(Modifier.height(20.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(24.dp).background(NeonRed, RoundedCornerShape(2.dp)))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("FINALIZAR SESIÓN", fontFamily = FontFamily.Monospace, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = Color.White)
                    Text("¿Qué deseas hacer?", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextTertiary)
                }
            }
            Spacer(Modifier.height(28.dp))
            // SAVE
            Box(
                modifier = Modifier.fillMaxWidth().height(60.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF8B0016), NeonRed, Color(0xFFCC001C))))
                    .drawBehind {
                        drawLine(
                            brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(0.28f), Color.White.copy(0.28f), Color.Transparent)),
                            start = Offset(size.width * 0.12f, 1.5f), end = Offset(size.width * 0.88f, 1.5f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .clickable { onSave() },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDone, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("GUARDAR SESIÓN", fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp, color = Color.White)
                }
            }
            Spacer(Modifier.height(10.dp))
            // CONTINUE
            Box(
                modifier = Modifier.fillMaxWidth().height(56.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NeonCyan.copy(0.10f))
                    .border(1.dp, NeonCyan.copy(0.40f), RoundedCornerShape(14.dp))
                    .clickable { onContinue() },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PlayArrow, null, tint = NeonCyan, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("CONTINUAR ENTRENANDO", fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = NeonCyan)
                }
            }
            Spacer(Modifier.height(10.dp))
            // DISCARD
            Box(
                modifier = Modifier.fillMaxWidth().height(50.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(NeonRedAlert.copy(0.07f))
                    .border(1.dp, NeonRedAlert.copy(0.25f), RoundedCornerShape(14.dp))
                    .clickable { onDiscard() },
                contentAlignment = Alignment.Center
            ) {
                Text("DESCARTAR SESIÓN", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, color = NeonRedAlert)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// ─── Discard workout overlay ──────────────────────────────────────────────────

// Pantalla de confirmación para descartar — alerta visual en rojo con advertencia clara antes de borrar todo
@Composable
private fun DiscardWorkoutOverlay(onConfirm: () -> Unit, onCancel: () -> Unit) {
    val infiniteTransition = rememberInfiniteTransition(label = "danger")
    val dangerPulse by infiniteTransition.animateFloat(
        initialValue = 0.15f, targetValue = 0.30f,
        animationSpec = infiniteRepeatable(tween(1000), RepeatMode.Reverse),
        label = "dp"
    )
    Box(
        modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.92f)),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.size(280.dp).alpha(dangerPulse).blur(110.dp)
            .background(Brush.radialGradient(listOf(NeonRedAlert, Color.Transparent)), CircleShape))
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xFF130303))
                .drawBehind {
                    drawRoundRect(color = NeonRedAlert.copy(0.40f), cornerRadius = CornerRadius(24.dp.toPx()), style = Stroke(1.5.dp.toPx()))
                }
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier.size(68.dp).background(NeonRedAlert.copy(0.15f), CircleShape).border(1.5.dp, NeonRedAlert.copy(0.55f), CircleShape),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Warning, null, tint = NeonRedAlert, modifier = Modifier.size(34.dp)) }
            Spacer(Modifier.height(16.dp))
            Text("¿DESCARTAR?", fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp, color = NeonRedAlert)
            Spacer(Modifier.height(8.dp))
            Text(
                "Se perderán TODOS los datos de esta sesión.\nEsta acción no se puede deshacer.",
                fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextSecondary,
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(28.dp))
            Box(
                modifier = Modifier.fillMaxWidth().height(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF6B0000), NeonRedAlert.copy(0.88f))))
                    .clickable { onConfirm() },
                contentAlignment = Alignment.Center
            ) { Text("DESCARTAR DEFINITIVAMENTE", fontFamily = FontFamily.Monospace, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.5.sp, color = Color.White) }
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier.fillMaxWidth().height(50.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color.White.copy(0.05f))
                    .border(1.dp, Color.White.copy(0.12f), RoundedCornerShape(12.dp))
                    .clickable { onCancel() },
                contentAlignment = Alignment.Center
            ) { Text("VOLVER AL ENTRENAMIENTO", fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextSecondary, letterSpacing = 0.5.sp) }
        }
    }
}

// ─── RPE overlay ──────────────────────────────────────────────────────────────

// Sheet para valorar el esfuerzo percibido de 1 a 10. El número y color cambian dinámicamente con el slider
@Composable
private fun RpeOverlay(selectedRpe: Int, onRpeSelected: (Int) -> Unit, hrSamples: List<Int>, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    val rpeColor = when {
        selectedRpe <= 3 -> NeonGreen
        selectedRpe <= 6 -> NeonYellow
        selectedRpe <= 8 -> Color(0xFFFF9100)
        else             -> NeonRedAlert
    }
    val rpeLabel = when (selectedRpe) { 1, 2 -> "MUY LIGERO"; 3, 4 -> "LIGERO"; 5, 6 -> "MODERADO"; 7, 8 -> "DURO"; 9 -> "MUY DURO"; 10 -> "ESFUERZO MÁXIMO"; else -> "" }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(0.92f)), contentAlignment = Alignment.BottomCenter) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(Color(0xFF0F0F0F))
                .drawBehind {
                    drawLine(
                        brush = Brush.horizontalGradient(
                            listOf(Color.Transparent, NeonRed.copy(0.60f), NeonRed.copy(0.60f), Color.Transparent),
                            startX = size.width * 0.08f, endX = size.width * 0.92f
                        ),
                        start = Offset(0f, 0f), end = Offset(size.width, 0f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }
                .padding(horizontal = 24.dp, vertical = 24.dp)
        ) {
            Box(Modifier.size(40.dp, 4.dp).align(Alignment.CenterHorizontally).background(Color.White.copy(0.12f), RoundedCornerShape(2.dp)))
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(3.dp).height(22.dp).background(NeonRed, RoundedCornerShape(2.dp)))
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("ESFUERZO PERCIBIDO", fontFamily = FontFamily.Monospace, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = Color.White)
                    Text("Escala CR10 de Borg", fontFamily = FontFamily.Monospace, fontSize = 10.sp, color = TextTertiary)
                }
            }
            if (hrSamples.size > 5) {
                Spacer(Modifier.height(14.dp))
                Text("FC DE LA SESIÓN", fontFamily = FontFamily.Monospace, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp, color = TextTertiary)
                Spacer(Modifier.height(6.dp))
                HrSparkline(samples = hrSamples, modifier = Modifier.fillMaxWidth().height(52.dp))
            }
            Spacer(Modifier.height(16.dp))
            // RPE number display
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("$selectedRpe", fontFamily = FontFamily.Monospace, fontSize = 60.sp, fontWeight = FontWeight.Black, color = rpeColor)
                    Text("/10", fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextTertiary, modifier = Modifier.padding(bottom = 10.dp))
                }
            }
            Text(rpeLabel, modifier = Modifier.fillMaxWidth(), fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = rpeColor, textAlign = TextAlign.Center, letterSpacing = 2.sp)
            Spacer(Modifier.height(14.dp))
            Slider(
                value = selectedRpe.toFloat(), onValueChange = { onRpeSelected(it.toInt()) },
                valueRange = 1f..10f, steps = 8,
                colors = SliderDefaults.colors(thumbColor = rpeColor, activeTrackColor = rpeColor, inactiveTrackColor = Color.White.copy(0.10f))
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("1 · Muy fácil", fontSize = 9.sp, color = NeonGreen, fontFamily = FontFamily.Monospace)
                Text("10 · Máximo", fontSize = 9.sp, color = StatusDanger, fontFamily = FontFamily.Monospace)
            }
            Spacer(Modifier.height(20.dp))
            Box(
                modifier = Modifier.fillMaxWidth().height(60.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF8B0016), NeonRed, Color(0xFFCC001C))))
                    .drawBehind {
                        drawLine(
                            brush = Brush.horizontalGradient(listOf(Color.Transparent, Color.White.copy(0.28f), Color.White.copy(0.28f), Color.Transparent)),
                            start = Offset(size.width * 0.12f, 1.5f), end = Offset(size.width * 0.88f, 1.5f),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                    .clickable { onConfirm() },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudDone, null, tint = Color.White, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("GUARDAR EN SUPABASE", fontFamily = FontFamily.Monospace, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp, color = Color.White)
                }
            }
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier.fillMaxWidth().height(44.dp).clickable { onDismiss() },
                contentAlignment = Alignment.Center
            ) { Text("Omitir RPE y guardar igualmente", fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextTertiary) }
            Spacer(Modifier.height(16.dp))
        }
    }
}