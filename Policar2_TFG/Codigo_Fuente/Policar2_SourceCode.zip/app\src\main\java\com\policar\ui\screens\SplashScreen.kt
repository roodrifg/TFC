package com.policar.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.policar.ui.theme.NeonCyan
import com.policar.ui.theme.NeonGreen
import com.policar.ui.theme.NeonRed
import com.policar.ui.theme.TextTertiary
import kotlinx.coroutines.delay

// Pantalla de arranque — muestra una secuencia de boot con líneas de sistema, scan line animada y el logo de Policar
@Composable
fun SplashScreen(onSplashComplete: () -> Unit) {
    var phase by remember { mutableIntStateOf(0) }
    var bootLines by remember { mutableStateOf(emptyList<Pair<String, Color>>()) }

    val logoAlpha by animateFloatAsState(
        targetValue = if (phase >= 3) 1f else 0f,
        animationSpec = tween(750, easing = FastOutSlowInEasing), label = "la"
    )
    val logoScale by animateFloatAsState(
        targetValue = if (phase >= 3) 1f else 0.84f,
        animationSpec = tween(950, easing = FastOutSlowInEasing), label = "ls"
    )
    val taglineAlpha by animateFloatAsState(
        targetValue = if (phase >= 4) 1f else 0f,
        animationSpec = tween(500), label = "ta"
    )
    val bootSectionAlpha by animateFloatAsState(
        targetValue = if (phase in 1..2) 1f else 0f,
        animationSpec = tween(350), label = "ba"
    )
    val bracketsAlpha by animateFloatAsState(
        targetValue = if (phase >= 1) 1f else 0f,
        animationSpec = tween(400), label = "bra"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "splash")
    val glow by infiniteTransition.animateFloat(
        initialValue = 0.40f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "g"
    )
    val scanY by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart),
        label = "scan"
    )

    LaunchedEffect(Unit) {
        delay(220)
        phase = 1
        bootLines = listOf("POLAR H10  INTERFACE" to NeonGreen)
        delay(380)
        bootLines = bootLines + ("BIOMECHANICS ENGINE" to NeonCyan)
        delay(300)
        bootLines = bootLines + ("HRV  ALGORITHM" to NeonCyan)
        delay(270)
        bootLines = bootLines + ("SUPABASE  SYNC" to NeonCyan)
        delay(300)
        phase = 2
        bootLines = bootLines + ("ALL  SYSTEMS  NOMINAL" to NeonGreen)
        delay(460)
        phase = 3
        delay(700)
        phase = 4
        delay(680)
        onSplashComplete()
    }

    val context = LocalContext.current
    val logoResId = remember {
        context.resources.getIdentifier("p_policar_sin_fondo", "drawable", context.packageName)
    }
    val hasLogo = remember(logoResId) { logoResId != 0 }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020202))
    ) {
        // Scan line overlay
        Canvas(modifier = Modifier.fillMaxSize()) {
            val pos = size.height * scanY
            val trail = size.height * 0.09f
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(Color.Transparent, NeonRed.copy(alpha = 0.05f), NeonRed.copy(alpha = 0.13f)),
                    startY = (pos - trail).coerceAtLeast(0f), endY = pos
                ),
                topLeft = Offset(0f, (pos - trail).coerceAtLeast(0f)),
                size = Size(size.width, trail.coerceAtMost(pos + 1))
            )
            drawLine(
                color = NeonRed.copy(alpha = 0.25f),
                start = Offset(0f, pos), end = Offset(size.width, pos),
                strokeWidth = 1.5.dp.toPx()
            )
            // Subtle horizontal grid lines
            for (i in 0..18) {
                drawLine(
                    color = NeonRed.copy(alpha = 0.012f),
                    start = Offset(0f, size.height * i / 18f),
                    end = Offset(size.width, size.height * i / 18f),
                    strokeWidth = 0.7f
                )
            }
        }

        // Large ambient glow
        Box(
            modifier = Modifier
                .size(500.dp).align(Alignment.Center).offset(y = (-20).dp)
                .alpha(glow * 0.28f)
                .background(Brush.radialGradient(listOf(NeonRed.copy(alpha = 0.52f), Color.Transparent)), CircleShape)
                .blur(150.dp)
        )
        Box(
            modifier = Modifier
                .size(230.dp).align(Alignment.Center).offset(y = (-20).dp)
                .alpha(glow * 0.20f)
                .background(Brush.radialGradient(listOf(NeonRed, Color.Transparent)), CircleShape)
                .blur(90.dp)
        )

        // Corner brackets
        Canvas(modifier = Modifier.fillMaxSize().alpha(bracketsAlpha)) {
            val pad = 28.dp.toPx()
            val arm = 32.dp.toPx()
            val sw = 1.8f
            val c = NeonRed.copy(alpha = 0.60f)
            // TL
            drawLine(c, Offset(pad, pad + arm), Offset(pad, pad), sw)
            drawLine(c, Offset(pad, pad), Offset(pad + arm, pad), sw)
            // TR
            drawLine(c, Offset(size.width - pad, pad + arm), Offset(size.width - pad, pad), sw)
            drawLine(c, Offset(size.width - pad, pad), Offset(size.width - pad - arm, pad), sw)
            // BL
            drawLine(c, Offset(pad, size.height - pad - arm), Offset(pad, size.height - pad), sw)
            drawLine(c, Offset(pad, size.height - pad), Offset(pad + arm, size.height - pad), sw)
            // BR
            drawLine(c, Offset(size.width - pad, size.height - pad - arm), Offset(size.width - pad, size.height - pad), sw)
            drawLine(c, Offset(size.width - pad, size.height - pad), Offset(size.width - pad - arm, size.height - pad), sw)
        }

        // Boot sequence lines — bottom area
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 116.dp, start = 36.dp, end = 36.dp)
                .alpha(bootSectionAlpha),
            horizontalAlignment = Alignment.Start
        ) {
            bootLines.forEachIndexed { index, (line, color) ->
                val isLast = index == bootLines.lastIndex
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = if (isLast && phase >= 2) "●" else "○",
                        fontSize = 7.sp,
                        color = color.copy(alpha = if (isLast) 1f else 0.55f),
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(Modifier.width(9.dp))
                    Text(
                        text = line,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp,
                        fontWeight = if (isLast) FontWeight.Bold else FontWeight.Normal,
                        letterSpacing = 1.8.sp,
                        color = color.copy(alpha = if (isLast) 1f else 0.40f)
                    )
                }
                Spacer(Modifier.height(5.dp))
            }
        }

        // Logo + tagline — centered
        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = (-28).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (hasLogo) {
                Image(
                    painter = painterResource(id = logoResId),
                    contentDescription = "POLICAR",
                    modifier = Modifier
                        .size(220.dp)
                        .alpha(logoAlpha)
                        .scale(logoScale),
                    contentScale = ContentScale.Fit
                )
            }

            Spacer(Modifier.height(28.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.alpha(taglineAlpha).padding(horizontal = 24.dp)
            ) {
                Box(
                    Modifier.weight(1f).height(1.dp)
                        .background(Brush.horizontalGradient(listOf(Color.Transparent, NeonRed.copy(alpha = 0.65f))))
                )
                Spacer(Modifier.width(18.dp))
                Text(
                    "PERFORMANCE TRACKER",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 3.2.sp,
                    color = TextTertiary.copy(alpha = 0.80f)
                )
                Spacer(Modifier.width(18.dp))
                Box(
                    Modifier.weight(1f).height(1.dp)
                        .background(Brush.horizontalGradient(listOf(NeonRed.copy(alpha = 0.65f), Color.Transparent)))
                )
            }
        }

        Text(
            text = "v1.0.0",
            fontFamily = FontFamily.Monospace,
            fontSize = 8.sp,
            color = TextTertiary.copy(alpha = 0.28f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 34.dp)
                .alpha(taglineAlpha)
        )
    }
}
