package com.policar.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.SportsTennis
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.policar.R
import com.policar.data.model.ConnectionState
import com.policar.data.model.ModoGrabacion
import com.policar.data.model.TipoDeporte
import com.policar.ui.components.*
import com.policar.ui.viewmodel.HomeUiState
import com.policar.ui.viewmodel.HomeViewModel
import com.policar.ui.viewmodel.HistoryViewModel
import com.policar.ui.theme.*
import com.polar.sdk.api.model.PolarDeviceInfo

// Pantalla principal donde el usuario conecta el sensor Polar, elige el deporte y arranca el entrenamiento
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    historyViewModel: HistoryViewModel,
    onStartWorkout: (TipoDeporte, ModoGrabacion) -> Unit,
    onNavigateToHistory: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val haptic = LocalHapticFeedback.current
    val configuration = LocalConfiguration.current

    val screenWidth = configuration.screenWidthDp
    val screenHeight = configuration.screenHeightDp
    val isCompact = screenWidth < 360
    val isTablet = screenWidth >= 600

    val horizontalPadding = when {
        isTablet -> 48.dp
        isCompact -> 12.dp
        else -> 20.dp
    }
    val scaleFactor = if (isTablet) 1.2f else if (isCompact) 0.85f else 1f
    val screenWidthDp = screenWidth.dp
    val screenHeightDp = screenHeight.dp

    var showContent by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(180)
        showContent = true
    }

    val ambientColor by animateColorAsState(
        targetValue = when (uiState.selectedDeporte) {
            TipoDeporte.FUTBOL   -> SportFutbol
            TipoDeporte.PADEL    -> SportPadel
            TipoDeporte.GIMNASIO -> SportGym
            null                 -> NeonRed
        },
        animationSpec = tween(700),
        label = "ambient"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040404))
    ) {
        // ─── Ambient glow layers ───────────────────────────────────────
        val g = screenWidthDp * 0.9f
        Box(Modifier.size(g).offset(x = (screenWidthDp - g) / 2, y = -g / 3)
            .alpha(0.24f).blur(90.dp)
            .background(Brush.radialGradient(listOf(ambientColor, Color.Transparent))))
        Box(Modifier.size(g * 0.5f).offset(x = screenWidthDp - g * 0.25f, y = screenHeightDp * 0.5f)
            .alpha(0.12f).blur(70.dp)
            .background(Brush.radialGradient(listOf(NeonCyan, Color.Transparent))))
        Box(Modifier.size(g * 0.6f).offset(x = (screenWidthDp - g * 0.6f) / 2, y = screenHeightDp * 0.74f)
            .alpha(0.13f).blur(70.dp)
            .background(Brush.radialGradient(listOf(ambientColor, Color.Transparent))))

        HudOverlay(modifier = Modifier.fillMaxSize(), showCornerBrackets = false,
            showScanLine = true, showGrid = true) {}

        // ─── Main scrollable content ───────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = horizontalPadding)
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(Modifier.height(22.dp))

            HeaderSection(
                connectionState = uiState.connectionState,
                onDisconnect = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    viewModel.disconnectDevice()
                },
                scaleFactor = scaleFactor
            )

            Spacer(Modifier.height((14 * scaleFactor).dp))

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(300))
            ) {
                SectionLabel(text = "DEVICE", scaleFactor = scaleFactor)
            }

            Spacer(Modifier.height((10 * scaleFactor).dp))

            // Connection card
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400)) + slideInVertically(tween(400) { it / 4 })
            ) {
                Column {
                    ConnectionSection(
                        uiState = uiState,
                        scaleFactor = scaleFactor,
                        onScanClick = { viewModel.startDeviceScan() }
                    )
                    DiscoveredDevicesList(
                        devices = uiState.discoveredDevices,
                        onDeviceClick = { viewModel.connectToDiscoveredDevice(it) },
                        scaleFactor = scaleFactor
                    )
                }
            }

            Spacer(Modifier.height((22 * scaleFactor).dp))

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(300, delayMillis = 60))
            ) {
                SectionLabel(text = "SELECT SPORT", scaleFactor = scaleFactor)
            }

            Spacer(Modifier.height((12 * scaleFactor).dp))

            Column(verticalArrangement = Arrangement.spacedBy((10 * scaleFactor).dp)) {
                TipoDeporte.entries.forEachIndexed { index, sport ->
                    val entryDelay = 80 + index * 65
                    AnimatedVisibility(
                        visible = showContent,
                        enter = fadeIn(tween(380, delayMillis = entryDelay)) +
                                slideInHorizontally(tween(380, delayMillis = entryDelay)) { -it / 5 }
                    ) {
                        SportCard(
                            sport = sport,
                            isSelected = uiState.selectedDeporte == sport,
                            onClick = {
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.selectDeporte(sport)
                            },
                            scaleFactor = scaleFactor
                        )
                    }
                }
            }

            Spacer(Modifier.height((24 * scaleFactor).dp))

            // START button
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(400, delayMillis = 320)) +
                        slideInVertically(tween(400, delayMillis = 320)) { it / 5 }
            ) {
                StartButton(
                    enabled = uiState.canStartWorkout,
                    mode = uiState.selectedModo,
                    onClick = {
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        val sport = uiState.selectedDeporte ?: return@StartButton
                        onStartWorkout(sport, uiState.selectedModo)
                    },
                    scaleFactor = scaleFactor
                )
            }

            Spacer(Modifier.height((12 * scaleFactor).dp))

            // Bottom row: compact mode toggle + history link
            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(350, delayMillis = 420))
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    AnimatedVisibility(
                        visible = uiState.selectedDeporte?.supportsOffline == true,
                        enter = fadeIn(tween(220)) + expandHorizontally(),
                        exit = fadeOut(tween(180)) + shrinkHorizontally()
                    ) {
                        ModeTogglePill(
                            selectedMode = uiState.selectedModo,
                            onModeSelected = { mode ->
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                viewModel.selectModo(mode)
                            },
                            scaleFactor = scaleFactor
                        )
                    }

                    // History link always at right
                    HistoryLink(
                        onClick = {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            onNavigateToHistory()
                        },
                        scaleFactor = scaleFactor
                    )
                }
            }

            Spacer(Modifier.height((40 * scaleFactor).dp))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Header
// ─────────────────────────────────────────────────────────────────────────────

// Cabecera con el logo de Policar, el subtítulo y el chip de estado de conexión en la esquina
@Composable
private fun HeaderSection(
    connectionState: ConnectionState,
    onDisconnect: () -> Unit,
    scaleFactor: Float
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Image(
                    painter = painterResource(id = R.drawable.logo_policar_sin_fondo),
                    contentDescription = "POLICAR",
                    modifier = Modifier
                        .height((44 * scaleFactor).dp)
                        .width((44 * scaleFactor).dp * 3f),
                    contentScale = ContentScale.Fit
                )
                Spacer(Modifier.height(3.dp))
                Text(
                    text = "PERFORMANCE TRACKER",
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = (7.5f * scaleFactor).sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 2.5.sp
                    ),
                    color = TextTertiary.copy(alpha = 0.55f)
                )
            }
            ConnectionChip(state = connectionState, onDisconnect = onDisconnect, scaleFactor = scaleFactor)
        }
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(
                            NeonRed.copy(alpha = 0.55f),
                            NeonRed.copy(alpha = 0.20f),
                            Color.Transparent
                        )
                    )
                )
        )
    }
}

// Pastilla de estado del sensor: verde si conectado, amarillo si buscando, gris si offline
@Composable
private fun ConnectionChip(
    state: ConnectionState,
    onDisconnect: () -> Unit,
    scaleFactor: Float
) {
    val infiniteTransition = rememberInfiniteTransition(label = "chip_pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.45f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "p"
    )
    val (indicatorColor, label, showDot) = when (state) {
        is ConnectionState.Scanning    -> Triple(NeonCyan,    "SEARCHING",   true)
        is ConnectionState.Connected   -> Triple(NeonGreen,   "ONLINE",      true)
        is ConnectionState.Connecting  -> Triple(NeonYellow,  "CONNECTING",  true)
        is ConnectionState.Reconnecting-> Triple(NeonOrange,  "RECONNECTING",true)
        is ConnectionState.Error       -> Triple(NeonRed,     "ERROR",       true)
        ConnectionState.Disconnected   -> Triple(TextTertiary,"OFFLINE",     false)
    }
    val isActive = state is ConnectionState.Scanning || state is ConnectionState.Connecting
            || state is ConnectionState.Reconnecting

    Surface(
        color = Color.Transparent,
        shape = RoundedCornerShape((20 * scaleFactor).dp),
        border = BorderStroke(1.dp, indicatorColor.copy(alpha = 0.28f))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(
                horizontal = (10 * scaleFactor).dp,
                vertical = (6 * scaleFactor).dp
            )
        ) {
            if (showDot) {
                Box(
                    modifier = Modifier
                        .size((6 * scaleFactor).dp)
                        .background(indicatorColor, CircleShape)
                        .alpha(if (isActive) pulse else 0.9f)
                )
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text = label,
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = (9 * scaleFactor).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                ),
                color = indicatorColor
            )
            if (state is ConnectionState.Connected) {
                Spacer(Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Disconnect",
                    tint = indicatorColor.copy(alpha = 0.4f),
                    modifier = Modifier
                        .size((12 * scaleFactor).dp)
                        .clickable(indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = onDisconnect)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Connection section — compact single-row card
// ─────────────────────────────────────────────────────────────────────────────

// Card del dispositivo Polar — al pulsar inicia el escaneo Bluetooth. Muestra anillos de radar mientras busca
@Composable
private fun ConnectionSection(
    uiState: HomeUiState,
    scaleFactor: Float,
    onScanClick: () -> Unit
) {
    val isConnected = uiState.connectionState.isConnected
    val isSearching = uiState.connectionState.isSearching
    val deviceId   = uiState.connectionState.deviceIdOrNull

    val statusColor = when {
        isConnected -> NeonGreen
        isSearching -> NeonYellow
        else        -> Color(0x1EFFFFFF)
    }
    val connCorner = (14 * scaleFactor).dp

    val radarTransition = rememberInfiniteTransition(label = "radar")
    val radarScale by radarTransition.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "rs"
    )
    val radarAlpha by radarTransition.animateFloat(
        initialValue = 0.65f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "ra"
    )
    val radarScale2 by radarTransition.animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart, initialStartOffset = StartOffset(550)),
        label = "rs2"
    )
    val radarAlpha2 by radarTransition.animateFloat(
        initialValue = 0.65f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart, initialStartOffset = StartOffset(550)),
        label = "ra2"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height((68 * scaleFactor).dp)
            .clip(RoundedCornerShape(connCorner))
            .background(
                brush = Brush.linearGradient(
                    colors = when {
                        isConnected -> listOf(NeonGreen.copy(alpha = 0.09f), Color(0xFF101010))
                        isSearching -> listOf(NeonYellow.copy(alpha = 0.08f), Color(0xFF101010))
                        else        -> listOf(Color(0xFF131313), Color(0xFF0E0E0E))
                    },
                    start = Offset(0f, 0f), end = Offset(600f, 0f)
                )
            )
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            statusColor.copy(alpha = 0.60f),
                            statusColor.copy(alpha = 0.15f),
                            statusColor.copy(alpha = 0.45f)
                        )
                    ),
                    cornerRadius = CornerRadius(connCorner.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = { if (!isConnected) onScanClick() }
            )
            .padding(horizontal = (14 * scaleFactor).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier.size((56 * scaleFactor).dp),
            contentAlignment = Alignment.Center
        ) {
            // Radar rings — only when scanning
            if (isSearching) {
                androidx.compose.foundation.Canvas(modifier = Modifier.matchParentSize()) {
                    val r1 = size.minDimension / 2 * radarScale
                    val r2 = size.minDimension / 2 * radarScale2
                    drawCircle(color = NeonYellow.copy(alpha = radarAlpha * 0.45f), radius = r1, style = Stroke(width = 1.2.dp.toPx()))
                    drawCircle(color = NeonYellow.copy(alpha = radarAlpha2 * 0.30f), radius = r2, style = Stroke(width = 0.8.dp.toPx()))
                }
            }
            Box(
                modifier = Modifier
                    .size((38 * scaleFactor).dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = when {
                                isConnected -> listOf(NeonGreen.copy(alpha = 0.22f), NeonGreen.copy(alpha = 0.02f))
                                isSearching -> listOf(NeonYellow.copy(alpha = 0.20f), NeonYellow.copy(alpha = 0.02f))
                                else        -> listOf(Color(0xFF1C1C1C), Color(0xFF111111))
                            }
                        ),
                        shape = CircleShape
                    )
                    .border(1.dp, statusColor.copy(alpha = if (isConnected || isSearching) 0.50f else 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isSearching) {
                    CircularProgressIndicator(
                        modifier = Modifier.size((18 * scaleFactor).dp),
                        color = NeonYellow, strokeWidth = 1.5.dp
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.Bluetooth,
                        contentDescription = null,
                        tint = if (isConnected) NeonGreen else TextTertiary,
                        modifier = Modifier.size((18 * scaleFactor).dp)
                    )
                }
            }
        }

        Spacer(Modifier.width((12 * scaleFactor).dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "POLAR H10",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = (12 * scaleFactor).sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                ),
                color = TextPrimary
            )
            Text(
                text = when {
                    isConnected -> deviceId ?: "Connected"
                    isSearching -> "Scanning for devices..."
                    else        -> "Tap to scan"
                },
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontSize = (9 * scaleFactor).sp
                ),
                color = when {
                    isConnected -> NeonGreen
                    isSearching -> NeonYellow
                    else        -> TextTertiary
                }
            )
        }

        if (isConnected) {
            Icon(Icons.Default.CheckCircle, contentDescription = null,
                tint = NeonGreen.copy(alpha = 0.75f),
                modifier = Modifier.size((18 * scaleFactor).dp))
        } else if (!isSearching) {
            Icon(Icons.Default.BluetoothDisabled, contentDescription = "Scan",
                tint = TextTertiary.copy(alpha = 0.45f),
                modifier = Modifier.size((18 * scaleFactor).dp))
        }
    }
}

// Lista de sensores encontrados durante el escaneo — pulsar uno lo conecta directamente
@Composable
private fun DiscoveredDevicesList(
    devices: List<PolarDeviceInfo>,
    onDeviceClick: (PolarDeviceInfo) -> Unit,
    scaleFactor: Float
) {
    if (devices.isEmpty()) return
    Column(modifier = Modifier.fillMaxWidth()) {
        Spacer(Modifier.height((8 * scaleFactor).dp))
        devices.forEach { device ->
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape((12 * scaleFactor).dp))
                    .background(Color(0xFF141414))
                    .border(1.dp, NeonCyan.copy(alpha = 0.18f), RoundedCornerShape((12 * scaleFactor).dp))
                    .clickable(
                        indication = null,
                        interactionSource = remember { MutableInteractionSource() },
                        onClick = { onDeviceClick(device) }
                    )
                    .padding((12 * scaleFactor).dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Bluetooth, null, tint = NeonCyan,
                        modifier = Modifier.size((16 * scaleFactor).dp))
                    Spacer(Modifier.width((10 * scaleFactor).dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = device.name ?: "Polar H10",
                            style = TextStyle(fontFamily = FontFamily.Monospace,
                                fontSize = (11 * scaleFactor).sp, fontWeight = FontWeight.Medium),
                            color = TextPrimary)
                        Text(text = device.deviceId,
                            style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = (9 * scaleFactor).sp),
                            color = TextTertiary)
                    }
                    Icon(Icons.Default.Add, "Connect", tint = NeonCyan,
                        modifier = Modifier.size((16 * scaleFactor).dp))
                }
            }
            Spacer(Modifier.height((6 * scaleFactor).dp))
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Sport card — sport-specific gradient background, prominent icon
// ─────────────────────────────────────────────────────────────────────────────

// Tarjeta de selección de deporte con icono, nombre y métricas. Se ilumina y anima al seleccionarla
@Composable
private fun SportCard(
    sport: TipoDeporte,
    isSelected: Boolean,
    onClick: () -> Unit,
    scaleFactor: Float
) {
    val cardHeight  = (138 * scaleFactor).dp
    val cardCorner  = (18 * scaleFactor).dp

    val sportColor = when (sport) {
        TipoDeporte.FUTBOL   -> SportFutbol
        TipoDeporte.PADEL    -> SportPadel
        TipoDeporte.GIMNASIO -> SportGym
    }
    // Each sport has its own permanent dark tint — the card is never generic gray
    val sportAmbient = when (sport) {
        TipoDeporte.FUTBOL   -> Color(0xFF062018)
        TipoDeporte.PADEL    -> Color(0xFF06132A)
        TipoDeporte.GIMNASIO -> Color(0xFF1E0900)
    }
    val sportIcon = when (sport) {
        TipoDeporte.FUTBOL   -> Icons.Default.SportsSoccer
        TipoDeporte.PADEL    -> Icons.Default.SportsTennis
        TipoDeporte.GIMNASIO -> Icons.Default.FitnessCenter
    }
    val sportMetrics = when (sport) {
        TipoDeporte.FUTBOL   -> "G-FORCE  ·  JUMP HEIGHT  ·  SPRINT"
        TipoDeporte.PADEL    -> "SERVE VELOCITY  ·  COURT MOVEMENT"
        TipoDeporte.GIMNASIO -> "REPS  ·  VELOCITY LOSS  ·  FORM"
    }

    val infiniteTransition = rememberInfiniteTransition(label = "sc_${sport.name}")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.5f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "p_${sport.name}"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(cardHeight)
            // Outer glow — drawn before clip so it extends beyond card edge
            .then(
                if (isSelected) Modifier.drawBehind {
                    val cr = cardCorner.toPx()
                    drawRoundRect(
                        color = sportColor.copy(alpha = pulse * 0.30f),
                        topLeft = Offset(-7f, -7f),
                        size = Size(size.width + 14, size.height + 14),
                        cornerRadius = CornerRadius(cr + 7)
                    )
                    drawRoundRect(
                        color = NeonRed.copy(alpha = pulse * 0.13f),
                        topLeft = Offset(-15f, -15f),
                        size = Size(size.width + 30, size.height + 30),
                        cornerRadius = CornerRadius(cr + 15)
                    )
                } else Modifier
            )
            .clip(RoundedCornerShape(cardCorner))
            // Horizontal gradient: sport color bleeds from left, fades to near-black
            .background(
                brush = Brush.horizontalGradient(
                    colors = if (isSelected) {
                        listOf(
                            sportColor.copy(alpha = 0.50f),
                            sportAmbient,
                            Color(0xFF0C0C0C)
                        )
                    } else {
                        listOf(sportAmbient, Color(0xFF0F0F0F))
                    }
                )
            )
            // Border — sport-colored on selected, subtle otherwise
            .then(
                if (isSelected) Modifier.drawBehind {
                    val cr = cardCorner.toPx()
                    drawRoundRect(
                        brush = Brush.linearGradient(
                            colors = listOf(
                                sportColor.copy(alpha = pulse * 0.95f),
                                sportColor.copy(alpha = pulse * 0.30f),
                                NeonRed.copy(alpha = pulse * 0.60f)
                            )
                        ),
                        cornerRadius = CornerRadius(cr),
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                    drawRect(
                        color = sportColor.copy(alpha = 0.90f),
                        topLeft = Offset(0f, 0f),
                        size = Size(4.dp.toPx(), size.height)
                    )
                } else Modifier.drawBehind {
                    val cr = cardCorner.toPx()
                    drawRoundRect(
                        brush = Brush.horizontalGradient(
                            colors = listOf(
                                sportColor.copy(alpha = 0.22f),
                                Color(0x0FFFFFFF),
                                Color(0x08FFFFFF)
                            )
                        ),
                        cornerRadius = CornerRadius(cr),
                        style = Stroke(width = 1.dp.toPx())
                    )
                    drawRect(
                        color = sportColor.copy(alpha = 0.35f),
                        topLeft = Offset(0f, 0f),
                        size = Size(3.dp.toPx(), size.height)
                    )
                }
            )
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
    ) {
        // Watermark icon — decorative, behind content
        Icon(
            imageVector = sportIcon,
            contentDescription = null,
            tint = sportColor.copy(alpha = if (isSelected) 0.10f else 0.065f),
            modifier = Modifier
                .size((108 * scaleFactor).dp)
                .align(Alignment.CenterEnd)
                .offset(x = (12 * scaleFactor).dp)
        )
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = (18 * scaleFactor).dp, vertical = (16 * scaleFactor).dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Icon box with glow
            Box(
                modifier = Modifier
                    .size((68 * scaleFactor).dp)
                    .then(
                        if (isSelected) Modifier.drawBehind {
                            drawCircle(
                                color = sportColor.copy(alpha = pulse * 0.32f),
                                radius = size.minDimension / 2 + 11.dp.toPx()
                            )
                        } else Modifier
                    )
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                sportColor.copy(alpha = if (isSelected) 0.36f else 0.22f),
                                sportColor.copy(alpha = if (isSelected) 0.08f else 0.03f)
                            )
                        ),
                        shape = CircleShape
                    )
                    .border(
                        width = 1.5.dp,
                        color = sportColor.copy(alpha = if (isSelected) 0.78f else 0.32f),
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = sportIcon,
                    contentDescription = null,
                    tint = sportColor,
                    modifier = Modifier.size((36 * scaleFactor).dp)
                )
            }

            Spacer(Modifier.width((16 * scaleFactor).dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = sport.displayName.uppercase(),
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = (20 * scaleFactor).sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    ),
                    color = if (isSelected) Color.White else TextPrimary
                )
                Spacer(Modifier.height((5 * scaleFactor).dp))
                Text(
                    text = sportMetrics,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = (8.5f * scaleFactor).sp,
                        letterSpacing = 0.3.sp
                    ),
                    color = if (isSelected) sportColor.copy(alpha = 0.75f) else TextTertiary,
                    maxLines = 1
                )
                if (sport.supportsOffline) {
                    Spacer(Modifier.height((5 * scaleFactor).dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size((3.5f * scaleFactor).dp)
                            .background(NeonRed.copy(alpha = 0.55f), CircleShape))
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "OFFLINE",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = (6.5f * scaleFactor).sp,
                                letterSpacing = 0.5.sp
                            ),
                            color = NeonRed.copy(alpha = 0.42f)
                        )
                    }
                }
            }

            // Selection checkmark
            AnimatedVisibility(
                visible = isSelected,
                enter = scaleIn(tween(180)) + fadeIn(tween(180)),
                exit  = scaleOut(tween(140)) + fadeOut(tween(140))
            ) {
                Box(
                    modifier = Modifier
                        .size((30 * scaleFactor).dp)
                        .background(
                            brush = Brush.radialGradient(listOf(sportColor, sportColor.copy(alpha = 0.45f))),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Check, null, tint = Color.White,
                        modifier = Modifier.size((16 * scaleFactor).dp))
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Start button
// ─────────────────────────────────────────────────────────────────────────────

// Botón principal para iniciar el entrenamiento. Desactivado hasta que hay deporte seleccionado y sensor conectado
@Composable
private fun StartButton(
    enabled: Boolean,
    mode: ModoGrabacion,
    onClick: () -> Unit,
    scaleFactor: Float
) {
    val infiniteTransition = rememberInfiniteTransition(label = "btn")
    val glow by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1400), RepeatMode.Reverse),
        label = "gw"
    )
    val shineX by infiniteTransition.animateFloat(
        initialValue = -0.30f, targetValue = 1.30f,
        animationSpec = infiniteRepeatable(
            tween(2000, easing = LinearEasing, delayMillis = 500),
            RepeatMode.Restart
        ),
        label = "shine"
    )

    val btnHeight   = (64 * scaleFactor).dp
    val btnCorner   = RoundedCornerShape((16 * scaleFactor).dp)

    Box(modifier = Modifier.fillMaxWidth().height(btnHeight + (18 * scaleFactor).dp)) {
        if (enabled) {
            Box(Modifier.fillMaxWidth(0.80f).height(btnHeight * 0.55f)
                .align(Alignment.BottomCenter).offset(y = (9 * scaleFactor).dp)
                .alpha(glow * 0.38f).blur(24.dp).background(NeonRed, RoundedCornerShape(50)))
            Box(Modifier.fillMaxWidth().height(btnHeight)
                .align(Alignment.BottomCenter)
                .alpha(glow * 0.16f).blur(16.dp).background(NeonRed, btnCorner))
        }

        Button(
            onClick = onClick, enabled = enabled,
            modifier = Modifier.fillMaxWidth().height(btnHeight).align(Alignment.BottomCenter),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent, contentColor = Color.White,
                disabledContainerColor = Color.Transparent, disabledContentColor = TextTertiary
            ),
            contentPadding = PaddingValues(0.dp), shape = btnCorner
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        brush = if (enabled) Brush.horizontalGradient(
                            listOf(Color(0xFF8B0016), NeonRed, Color(0xFFCC001C))
                        ) else Brush.horizontalGradient(
                            listOf(Color(0xFF181818), Color(0xFF1C1C1C), Color(0xFF181818))
                        ),
                        shape = btnCorner
                    )
                    .then(
                        if (enabled) Modifier.drawBehind {
                            // Top highlight line
                            drawLine(
                                brush = Brush.horizontalGradient(listOf(
                                    Color.Transparent, Color.White.copy(alpha = 0.30f),
                                    Color.White.copy(alpha = 0.30f), Color.Transparent
                                )),
                                start = Offset(size.width * 0.12f, 1.5f),
                                end   = Offset(size.width * 0.88f, 1.5f),
                                strokeWidth = 1.dp.toPx()
                            )
                            // Sweeping shine
                            val sw = size.width * 0.18f
                            val cx = size.width * shineX
                            drawRect(
                                brush = Brush.horizontalGradient(
                                    colors = listOf(
                                        Color.Transparent,
                                        Color.White.copy(alpha = 0.10f),
                                        Color.White.copy(alpha = 0.22f),
                                        Color.White.copy(alpha = 0.10f),
                                        Color.Transparent
                                    ),
                                    startX = cx - sw,
                                    endX   = cx + sw
                                )
                            )
                        } else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    if (enabled) {
                        Icon(
                            imageVector = if (mode == ModoGrabacion.EN_VIVO)
                                Icons.Default.PlayArrow else Icons.Default.FiberManualRecord,
                            contentDescription = null, tint = Color.White,
                            modifier = Modifier.size((22 * scaleFactor).dp)
                        )
                        Spacer(Modifier.width((10 * scaleFactor).dp))
                    }
                    Text(
                        text = when {
                            !enabled -> "SELECT A SPORT TO BEGIN"
                            mode == ModoGrabacion.EN_VIVO -> "START TELEMETRY"
                            else -> "START RECORDING"
                        },
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = (13 * scaleFactor).sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 2.sp
                        ),
                        color = if (enabled) Color.White else TextTertiary
                    )
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Mode toggle pill — compact segmented control
// ─────────────────────────────────────────────────────────────────────────────

// Selector entre modo LIVE (telemetría en tiempo real) y REC (grabación offline en el sensor)
@Composable
private fun ModeTogglePill(
    selectedMode: ModoGrabacion,
    onModeSelected: (ModoGrabacion) -> Unit,
    scaleFactor: Float
) {
    val pillCorner  = (20 * scaleFactor).dp
    val innerCorner = (16 * scaleFactor).dp

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(pillCorner))
            .background(Color(0xFF121212))
            .drawBehind {
                drawRoundRect(
                    color = Color(0x1AFFFFFF),
                    cornerRadius = CornerRadius(pillCorner.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
            }
    ) {
        Row(modifier = Modifier.padding(3.dp), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            ModoGrabacion.entries.forEach { mode ->
                val isSel = mode == selectedMode
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(innerCorner))
                        .background(if (isSel) NeonRed.copy(alpha = 0.92f) else Color.Transparent)
                        .clickable(
                            indication = null,
                            interactionSource = remember { MutableInteractionSource() },
                            onClick = { onModeSelected(mode) }
                        )
                        .padding(
                            horizontal = (11 * scaleFactor).dp,
                            vertical = (6 * scaleFactor).dp
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size((5 * scaleFactor).dp)
                                .background(
                                    if (isSel) Color.White else TextTertiary.copy(alpha = 0.6f),
                                    CircleShape
                                )
                        )
                        Spacer(Modifier.width(5.dp))
                        Text(
                            text = when (mode) {
                                ModoGrabacion.EN_VIVO -> "LIVE"
                                ModoGrabacion.OFFLINE -> "REC"
                            },
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = (9 * scaleFactor).sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 0.5.sp
                            ),
                            color = if (isSel) Color.White else TextTertiary
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  Section label — red accent bar + bold uppercase label + fade-out line
// ─────────────────────────────────────────────────────────────────────────────

// Etiqueta de sección con barra roja vertical y línea decorativa — organiza visualmente la pantalla
@Composable
private fun SectionLabel(text: String, scaleFactor: Float) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Box(
            Modifier
                .width(3.dp)
                .height((13 * scaleFactor).dp)
                .background(
                    brush = Brush.verticalGradient(listOf(NeonRed, NeonRed.copy(alpha = 0.15f))),
                    shape = RoundedCornerShape(2.dp)
                )
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = text,
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontSize = (10 * scaleFactor).sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.5.sp
            ),
            color = TextSecondary
        )
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier
                .weight(1f)
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(NeonRed.copy(alpha = 0.30f), Color.Transparent)
                    )
                )
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
//  History link — minimal inline text button
// ─────────────────────────────────────────────────────────────────────────────

// Enlace al historial de sesiones, siempre visible en la parte inferior derecha
@Composable
private fun HistoryLink(
    onClick: () -> Unit,
    scaleFactor: Float
) {
    Row(
        modifier = Modifier
            .clickable(
                indication = null,
                interactionSource = remember { MutableInteractionSource() },
                onClick = onClick
            )
            .padding(horizontal = (6 * scaleFactor).dp, vertical = (8 * scaleFactor).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.Analytics,
            contentDescription = null,
            tint = NeonCyan.copy(alpha = 0.55f),
            modifier = Modifier.size((15 * scaleFactor).dp)
        )
        Spacer(Modifier.width(5.dp))
        Text(
            text = "HISTORY",
            style = TextStyle(
                fontFamily = FontFamily.Monospace,
                fontSize = (10 * scaleFactor).sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            ),
            color = NeonCyan.copy(alpha = 0.55f)
        )
        Spacer(Modifier.width(2.dp))
        Icon(
            imageVector = Icons.Default.KeyboardArrowRight,
            contentDescription = null,
            tint = NeonCyan.copy(alpha = 0.40f),
            modifier = Modifier.size((14 * scaleFactor).dp)
        )
    }
}
