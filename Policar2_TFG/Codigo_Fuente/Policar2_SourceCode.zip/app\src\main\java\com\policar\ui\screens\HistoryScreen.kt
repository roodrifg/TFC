package com.policar.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.SportsTennis
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Sports
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.policar.data.model.CalendarDay
import com.policar.data.model.FutbolBiomechanics
import com.policar.data.model.GymBiomechanics
import com.policar.data.model.PadelBiomechanics
import com.policar.data.model.TipoDeporte
import com.policar.data.model.TrainingSession
import com.policar.data.model.ViewPeriod
import kotlinx.serialization.json.Json
import com.policar.ui.components.*
import com.policar.ui.theme.*
import com.policar.ui.viewmodel.HistoryViewModel
import com.policar.R

private val BorderSubtle = Color.White.copy(alpha = 0.06f)

// Pantalla de historial con calendario interactivo y lista de sesiones del período seleccionado
@Composable
fun HistoryScreen(
    viewModel: HistoryViewModel,
    navController: NavController,
    onNavigateToDashboard: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    var showContent by remember { mutableStateOf(false) }

    BackHandler(enabled = uiState.selectedSession != null) {
        viewModel.clearSelectedSession()
    }

    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(100)
        showContent = true
        viewModel.setUserId("demo_user")
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040404))
    ) {
        // Ambient glows
        Box(Modifier.size(300.dp).offset(x = (-50).dp, y = (-80).dp)
            .alpha(0.16f).blur(80.dp)
            .background(Brush.radialGradient(listOf(NeonRed, Color.Transparent))))
        Box(Modifier.size(220.dp).offset(x = 220.dp, y = 500.dp)
            .alpha(0.10f).blur(70.dp)
            .background(Brush.radialGradient(listOf(NeonCyan, Color.Transparent))))
        uiState.selectedSession?.let { session ->
            SessionDetailView(
                session = session,
                onClose = { viewModel.clearSelectedSession() },
                formatDuration = { viewModel.formatDuration(it) },
                formatDateFull = { viewModel.formatDateFull(it) }
            )
        } ?: Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    Column {
                        Text(
                            text = "HISTORY",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 3.sp
                            ),
                            color = TextPrimary
                        )
                        Text(
                            text = "TRAINING LOG",
                            style = TextStyle(
                                fontFamily = FontFamily.Monospace,
                                fontSize = 8.sp,
                                letterSpacing = 2.sp
                            ),
                            color = TextTertiary.copy(alpha = 0.55f)
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onNavigateToDashboard) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .background(NeonCyan.copy(alpha = 0.10f), androidx.compose.foundation.shape.CircleShape)
                                .border(1.dp, NeonCyan.copy(alpha = 0.30f), androidx.compose.foundation.shape.CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Analytics,
                                contentDescription = "Dashboard",
                                tint = NeonCyan,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Box(
                Modifier.fillMaxWidth().height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(NeonRed.copy(alpha = 0.50f), NeonRed.copy(alpha = 0.15f), Color.Transparent)
                        )
                    )
            )

            Spacer(modifier = Modifier.height(16.dp))

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(300)) + slideInVertically(tween(300) { it / 4 })
            ) {
                PeriodSelector(
                    selectedPeriod = uiState.selectedPeriod,
                    onPeriodSelected = { viewModel.selectPeriod(it) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (uiState.sessions.isNotEmpty()) {
                AnimatedVisibility(
                    visible = showContent,
                    enter = fadeIn(tween(300, delayMillis = 60))
                ) {
                    WeeklyStatsStrip(sessions = uiState.sessions, period = uiState.selectedPeriod)
                }
                Spacer(modifier = Modifier.height(12.dp))
            } else {
                Spacer(modifier = Modifier.height(4.dp))
            }

            AnimatedVisibility(
                visible = showContent,
                enter = fadeIn(tween(300, delayMillis = 100)) + slideInVertically(tween(300, delayMillis = 100) { it / 4 })
            ) {
                CalendarView(
                    calendarDays = uiState.calendarDays,
                    selectedDate = uiState.selectedDate,
                    period = uiState.selectedPeriod,
                    onDateSelected = { viewModel.selectDate(it) }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (uiState.isLoading) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        color = NeonRed,
                        modifier = Modifier.size(32.dp)
                    )
                }
            } else {
                val sessionsForDate = viewModel.getSessionsForDate(uiState.selectedDate)

                if (sessionsForDate.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "NO SESSIONS",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 2.sp
                                ),
                                color = TextTertiary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "for this period",
                                style = TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 11.sp
                                ),
                                color = TextTertiary.copy(alpha = 0.5f)
                            )
                        }
                    }
                } else {
                    Text(
                        text = "${sessionsForDate.size} SESSIONS",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 2.sp
                        ),
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(sessionsForDate) { session ->
                            SessionCard(
                                session = session,
                                onClick = { viewModel.selectSession(session) },
                                onDelete = { viewModel.deleteSession(session.id) },
                                formatDuration = { viewModel.formatDuration(it) },
                                formatTime = { viewModel.formatTime(session.startTimestamp) }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

// Tarjeta de sesión en la lista — muestra el deporte, la hora, la duración y la FC media de forma compacta
@Composable
private fun SessionCard(
    session: TrainingSession,
    onClick: () -> Unit,
    onDelete: () -> Unit,
    formatDuration: (Int) -> String,
    formatTime: (Long) -> String
) {
    val sportColor = when (session.sportType.lowercase()) {
        "futbol" -> SportFutbol
        "padel" -> SportPadel
        "gimnasio" -> SportGym
        else -> NeonCyan
    }

    val sportIcon: ImageVector = when (session.sportType.lowercase()) {
        "futbol" -> Icons.Default.SportsSoccer
        "padel" -> Icons.Default.SportsTennis
        else -> Icons.Default.FitnessCenter
    }

    val sportAmbient = when (session.sportType.lowercase()) {
        "futbol" -> Color(0xFF062018)
        "padel" -> Color(0xFF06132A)
        "gimnasio" -> Color(0xFF1E0900)
        else -> Color(0xFF111111)
    }
    val cardCorner = 16.dp

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(cardCorner))
            .background(
                brush = Brush.horizontalGradient(
                    colors = listOf(sportAmbient, Color(0xFF0F0F0F))
                )
            )
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            sportColor.copy(alpha = 0.38f),
                            Color(0x0DFFFFFF),
                            Color(0x08FFFFFF)
                        )
                    ),
                    cornerRadius = CornerRadius(cardCorner.toPx()),
                    style = Stroke(width = 1.dp.toPx())
                )
                // Left sport accent bar
                drawRect(
                    color = sportColor.copy(alpha = 0.80f),
                    topLeft = Offset(0f, 0f),
                    size = Size(3.5.dp.toPx(), size.height)
                )
            }
            .clickable { onClick() }
            .padding(16.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .background(
                        sportColor.copy(alpha = 0.1f),
                        CircleShape
                    )
                    .border(1.dp, sportColor.copy(alpha = 0.3f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = sportIcon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = session.sportType.uppercase(),
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.5.sp
                    ),
                    color = sportColor
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AccessTime,
                        contentDescription = null,
                        tint = TextTertiary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = formatTime(session.startTimestamp),
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        color = TextSecondary
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = formatDuration(session.durationSeconds),
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        ),
                        color = TextSecondary
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = NeonRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${session.hrAvg.toInt()}",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black
                        ),
                        color = NeonRed
                    )
                    Text(
                        text = " BPM",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        ),
                        color = TextTertiary
                    )
                }

                if (session.rpe > 0) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "RPE ${session.rpe}/10",
                        style = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        ),
                        color = TextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextTertiary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

// Vista detallada de una sesión: card hero con el deporte, métricas de FC, zonas cardíacas y biomecánica específica
@Composable
private fun SessionDetailView(
    session: TrainingSession,
    onClose: () -> Unit,
    formatDuration: (Int) -> String,
    formatDateFull: (Long) -> String
) {
    val json = remember { Json { ignoreUnknownKeys = true } }
    val futbolBio = remember(session.id) {
        session.futbolBiomechanics?.let {
            runCatching { json.decodeFromJsonElement(FutbolBiomechanics.serializer(), it) }.getOrNull()
        }
    }
    val padelBio = remember(session.id) {
        session.padelBiomechanics?.let {
            runCatching { json.decodeFromJsonElement(PadelBiomechanics.serializer(), it) }.getOrNull()
        }
    }
    val gymBio = remember(session.id) {
        session.gymBiomechanics?.let {
            runCatching { json.decodeFromJsonElement(GymBiomechanics.serializer(), it) }.getOrNull()
        }
    }

    val sportColor = when (session.sportType.uppercase()) {
        "FUTBOL" -> SportFutbol
        "PADEL" -> SportPadel
        "GIMNASIO" -> SportGym
        else -> NeonCyan
    }
    val sportIcon: ImageVector = when (session.sportType.uppercase()) {
        "FUTBOL" -> Icons.Default.SportsSoccer
        "PADEL" -> Icons.Default.SportsTennis
        else -> Icons.Default.FitnessCenter
    }

    val sportAmbient = when (session.sportType.uppercase()) {
        "FUTBOL"   -> Color(0xFF062018)
        "PADEL"    -> Color(0xFF06132A)
        "GIMNASIO" -> Color(0xFF1E0900)
        else       -> Color(0xFF111111)
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF030303))) {
        // Sport ambient glow
        Box(
            Modifier.size(280.dp).offset(x = 120.dp, y = (-50).dp)
                .alpha(0.20f).blur(100.dp)
                .background(Brush.radialGradient(listOf(sportColor, Color.Transparent)), CircleShape)
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Minimal back bar
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onClose) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary)
                }
                Text(
                    text = "SESSION DETAIL",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = TextTertiary.copy(alpha = 0.60f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Hero card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(sportAmbient, Color(0xFF0E0E0E))))
                    .drawBehind {
                        drawRoundRect(
                            brush = Brush.linearGradient(listOf(sportColor.copy(0.50f), sportColor.copy(0.10f), Color(0x08FFFFFF))),
                            cornerRadius = CornerRadius(20.dp.toPx()), style = Stroke(1.5.dp.toPx())
                        )
                        drawRect(color = sportColor.copy(0.88f), topLeft = Offset(0f, 0f), size = Size(4.dp.toPx(), size.height))
                    }
                    .padding(20.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(76.dp)
                            .background(sportColor.copy(0.18f), CircleShape)
                            .border(1.5.dp, sportColor.copy(0.65f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(sportIcon, null, tint = sportColor, modifier = Modifier.size(42.dp))
                    }
                    Spacer(modifier = Modifier.width(18.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = session.sportType.uppercase(),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp,
                            color = sportColor
                        )
                        Spacer(Modifier.height(3.dp))
                        Text(text = formatDateFull(session.startTimestamp), fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextSecondary)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color.White.copy(0.08f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(formatDuration(session.durationSeconds), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                            }
                            if (session.rpe > 0) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(NeonYellow.copy(0.12f))
                                        .border(1.dp, NeonYellow.copy(0.35f), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text("RPE ${session.rpe}/10", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = NeonYellow)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                DetailStatCard(modifier = Modifier.weight(1f), label = "FC MEDIA", value = "${session.hrAvg.toInt()}", color = NeonRed)
                DetailStatCard(modifier = Modifier.weight(1f), label = "FC MAX", value = "${session.hrMax}", color = StatusDanger)
                DetailStatCard(modifier = Modifier.weight(1f), label = "FC MIN", value = "${session.hrMin}", color = NeonGreen)
            }

            val totalZoneSeconds = session.zone1Seconds + session.zone2Seconds + session.zone3Seconds + session.zone4Seconds + session.zone5Seconds
            if (totalZoneSeconds > 0) {
                Spacer(modifier = Modifier.height(16.dp))
                DetailSectionHeader(title = "ZONAS FC", color = NeonRed, icon = Icons.Default.Favorite)
                Spacer(modifier = Modifier.height(10.dp))
                ZonesDetailRow(session = session, total = totalZoneSeconds)
            }

            when (session.sportType.uppercase()) {
                "FUTBOL" -> futbolBio?.let { bio ->
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailSectionHeader(title = "BIOMECANICA · FUTBOL", color = sportColor, icon = Icons.Default.SportsSoccer)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "IMPACTOS", value = "${bio.totalImpacts}", color = sportColor)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "ALTA INTENS.", value = "${bio.highIntensityImpacts}", color = StatusDanger)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "G MAX", value = "${"%.1f".format(bio.maxGForce)} G", color = NeonYellow)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "SPRINTS", value = "${bio.sprintCount}", color = NeonYellow)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "SALTOS", value = "${bio.jumpCount}", color = NeonCyan)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "ASIMETRIA", value = "${"%.0f".format(bio.asymmetryScore)}%", color = if (bio.asymmetryScore < 15f) NeonGreen else NeonYellow)
                    }
                }
                "PADEL" -> padelBio?.let { bio ->
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailSectionHeader(title = "BIOMECANICA · PADEL", color = sportColor, icon = Icons.Default.SportsTennis)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "SMASHES", value = "${bio.totalSmashes}", color = sportColor)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "ROT. MEDIA", value = "${"%.0f".format(bio.avgRotationDps)} d/s", color = NeonCyan)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "ROT. MAX", value = "${"%.0f".format(bio.maxRotationDps)} d/s", color = NeonYellow)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "ASIMETRIA", value = "${"%.0f".format(bio.asymmetryScore * 100)}%", color = if (bio.asymmetryScore < 0.2f) NeonGreen else NeonYellow)
                    }
                }
                "GIMNASIO" -> gymBio?.let { bio ->
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailSectionHeader(title = "BIOMECANICA · GYM", color = sportColor, icon = Icons.Default.FitnessCenter)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "REPS", value = "${bio.totalReps}", color = sportColor)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "SERIES", value = "${bio.totalSets}", color = NeonYellow)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "VEL. MEDIA", value = "${"%.2f".format(bio.avgVelocityMs)} m/s", color = NeonGreen)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DetailStatCard(modifier = Modifier.weight(1f), label = "PERD. VEL.", value = "${"%.0f".format(bio.velocityLossPct)}%", color = if (bio.velocityLossPct < 20f) NeonGreen else StatusDanger)
                        DetailStatCard(modifier = Modifier.weight(1f), label = "FATIGA", value = "${"%.1f".format(bio.fatigueIndex)}", color = NeonCyan)
                    }
                }
            }

            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

// Tarjeta pequeña de estadística con borde y acento en el color del dato — se usa en la vista de detalle
@Composable
private fun DetailStatCard(modifier: Modifier = Modifier, label: String, value: String, color: Color) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(Color(0xFF1C1C1C), Color(0xFF101010))))
            .drawBehind {
                val cr = 12.dp.toPx()
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(color.copy(alpha = 0.35f), Color(0x0AFFFFFF), Color(0x06FFFFFF))),
                    cornerRadius = CornerRadius(cr), style = Stroke(1.dp.toPx())
                )
                drawLine(
                    brush = Brush.horizontalGradient(
                        listOf(Color.Transparent, color.copy(0.80f), color.copy(0.80f), Color.Transparent),
                        startX = size.width * 0.08f, endX = size.width * 0.92f
                    ),
                    start = Offset(0f, 0f), end = Offset(size.width, 0f),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
            .padding(12.dp)
    ) {
        Column {
            Text(text = value, fontWeight = FontWeight.Black, fontSize = 20.sp, color = color, fontFamily = FontFamily.Monospace)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = label, fontSize = 7.5.sp, color = TextTertiary.copy(alpha = 0.65f), letterSpacing = 0.8.sp, fontFamily = FontFamily.Monospace)
        }
    }
}

// Cabecera de sección con barra de color, icono y línea decorativa para separar grupos de métricas
@Composable
private fun DetailSectionHeader(title: String, color: Color, icon: ImageVector) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Box(Modifier.width(3.dp).height(18.dp).background(Brush.verticalGradient(listOf(color, color.copy(0.08f))), RoundedCornerShape(2.dp)))
        Spacer(modifier = Modifier.width(10.dp))
        Box(
            modifier = Modifier.size(30.dp).background(color.copy(0.16f), RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(9.dp))
        Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = color, letterSpacing = 1.5.sp, fontFamily = FontFamily.Monospace)
        Spacer(modifier = Modifier.width(12.dp))
        Box(Modifier.weight(1f).height(1.dp).background(Brush.horizontalGradient(listOf(color.copy(0.32f), Color.Transparent))))
    }
}

// Gráfico de barras de zonas cardíacas con animación, porcentaje de tiempo en cada zona y etiquetas Z1-Z5
@Composable
private fun ZonesDetailRow(session: TrainingSession, total: Int) {
    val zoneColors = listOf(StatusGood, NeonGreen, NeonYellow, Color(0xFFFF9100), StatusDanger)
    val zoneLabels = listOf("Z1", "Z2", "Z3", "Z4", "Z5")
    val zoneSeconds = listOf(session.zone1Seconds, session.zone2Seconds, session.zone3Seconds, session.zone4Seconds, session.zone5Seconds)

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF111111))
            .padding(16.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            zoneSeconds.forEachIndexed { i, secs ->
                val fraction = if (total > 0) secs.toFloat() / total else 0f
                val animFraction by animateFloatAsState(targetValue = fraction, animationSpec = tween(600), label = "z$i")
                val pct = (fraction * 100).toInt()
                Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (pct > 0) {
                        Text(text = "$pct%", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = zoneColors[i], fontFamily = FontFamily.Monospace)
                    } else {
                        Spacer(Modifier.height(12.dp))
                    }
                    Spacer(Modifier.height(4.dp))
                    Box(modifier = Modifier.fillMaxWidth().height(52.dp), contentAlignment = Alignment.BottomCenter) {
                        // Background track
                        Box(
                            modifier = Modifier.fillMaxWidth(0.75f).fillMaxHeight()
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(zoneColors[i].copy(alpha = 0.08f))
                        )
                        // Filled bar
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.75f)
                                .fillMaxHeight(maxOf(animFraction, if (fraction > 0.01f) 0.06f else 0f))
                                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                .background(
                                    Brush.verticalGradient(
                                        listOf(zoneColors[i], zoneColors[i].copy(alpha = 0.60f))
                                    )
                                )
                        )
                    }
                    Spacer(modifier = Modifier.height(5.dp))
                    Text(text = zoneLabels[i], fontSize = 10.sp, color = zoneColors[i], fontWeight = FontWeight.ExtraBold, fontFamily = FontFamily.Monospace)
                    val mins = secs / 60
                    val s = secs % 60
                    Text(text = "${mins}:${"%02d".format(s)}", fontSize = 7.sp, color = TextTertiary.copy(0.65f), fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

// Franja de resumen del período: total de sesiones, tiempo acumulado y FC media en tres celdas
@Composable
private fun WeeklyStatsStrip(sessions: List<com.policar.data.model.TrainingSession>, period: com.policar.data.model.ViewPeriod) {
    val totalSessions = sessions.size
    val totalMinutes = sessions.sumOf { it.durationSeconds } / 60
    val avgHr = sessions.filter { it.hrAvg > 0f }.map { it.hrAvg }.takeIf { it.isNotEmpty() }?.average()?.toInt() ?: 0
    val hours = totalMinutes / 60
    val mins = totalMinutes % 60
    val timeStr = if (hours > 0) "${hours}h ${mins}m" else "${mins}m"

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF181818), Color(0xFF101010))))
            .drawBehind {
                drawRoundRect(
                    brush = Brush.linearGradient(listOf(NeonRed.copy(alpha = 0.22f), Color(0x0AFFFFFF), Color(0x06FFFFFF))),
                    cornerRadius = CornerRadius(14.dp.toPx()), style = Stroke(1.dp.toPx())
                )
            }
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        StripStat(label = "SESIONES", value = "$totalSessions", color = NeonCyan)
        Box(Modifier.width(1.dp).height(30.dp).background(Color.White.copy(alpha = 0.07f)))
        StripStat(label = "TIEMPO", value = timeStr, color = NeonGreen)
        Box(Modifier.width(1.dp).height(30.dp).background(Color.White.copy(alpha = 0.07f)))
        StripStat(label = "FC MEDIA", value = if (avgHr > 0) "$avgHr" else "--", color = NeonRed, unit = if (avgHr > 0) "bpm" else "")
    }
}

// Celda individual dentro del strip de estadísticas: etiqueta pequeña y valor en grande
@Composable
private fun StripStat(label: String, value: String, color: Color, unit: String = "") {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                text = value,
                style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 22.sp, fontWeight = FontWeight.Black),
                color = color
            )
            if (unit.isNotBlank()) {
                Spacer(Modifier.width(2.dp))
                Text(
                    text = unit,
                    style = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 9.sp),
                    color = TextTertiary,
                    modifier = Modifier.padding(bottom = 3.dp)
                )
            }
        }
        Spacer(Modifier.height(1.dp))
        Text(text = label, fontSize = 7.sp, color = TextTertiary.copy(alpha = 0.55f), letterSpacing = 1.sp, fontFamily = FontFamily.Monospace)
    }
}
